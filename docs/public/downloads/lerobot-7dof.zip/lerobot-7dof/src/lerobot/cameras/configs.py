#!/usr/bin/env python

# Copyright 2024 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import abc
from dataclasses import dataclass
from enum import Enum

import draccus  # type: ignore  # TODO: add type stubs for draccus


class ColorMode(str, Enum):
    RGB = "rgb"
    BGR = "bgr"

    @classmethod
    def _missing_(cls, value: object) -> None:
        raise ValueError(f"`color_mode` is expected to be in {list(cls)}, but {value} is provided.")


class Cv2Rotation(int, Enum):
    NO_ROTATION = 0
    ROTATE_90 = 90
    ROTATE_180 = 180
    ROTATE_270 = -90

    @classmethod
    def _missing_(cls, value: object) -> None:
        raise ValueError(f"`rotation` is expected to be in {list(cls)}, but {value} is provided.")


# Subset from https://docs.opencv.org/3.4/d4/d15/group__videoio__flags__base.html
class Cv2Backends(int, Enum):
    ANY = 0
    V4L2 = 200
    DSHOW = 700
    PVAPI = 800
    ANDROID = 1000
    AVFOUNDATION = 1200
    MSMF = 1400

    @classmethod
    def _missing_(cls, value: object) -> None:
        raise ValueError(f"`backend` is expected to be in {list(cls)}, but {value} is provided.")


@dataclass(kw_only=True)
class CameraConfig(draccus.ChoiceRegistry, abc.ABC):  # type: ignore  # TODO: add type stubs for draccus
    fps: int | None = None
    width: int | None = None
    height: int | None = None

    @property
    def type(self) -> str:
        return str(self.get_choice_name(self.__class__))
