# SO-ARM101 ROS 2 Simulation

Complete ROS 2 workspace for the **SO-ARM101** 6-DoF robotic arm, covering
robot description, built-in hardware driver, Gazebo simulation, and MoveIt 2 motion
planning — all in a single repository.

The SO-ARM101 is the second-generation open-source follower arm co-designed by
[TheRobotStudio](https://www.therobotstudio.com/) and the
[LeRobot](https://huggingface.co/lerobot) community. It uses six STS3215
servos, a servo driver board, and 3D-printed PLA+ parts.

**Note: The arm requires center calibration — perform it with all joints at the**
**middle of their range of motion.**

---

## Packages

| Package | Purpose |
|---------|---------|
| `so_arm_utils` | Shared Python helpers |
| `so_arm101_description` | URDF/XACRO model, ros2_control interface, RViz & MuJoCo config |
| `so_arm101_moveit_config` | MoveIt 2: SRDF, kinematics, joint limits, OMPL planners |
| `so_arm_gz` | Gazebo simulator launcher with ros2_control integration |
| `so_arm_hardware` | **Built-in** SCS serial driver for STS3215 servos (no external deps) |

Targets **ROS 2 Humble / Jazzy**.

---

## 0.  Environment Setup

Before building this project, ensure ROS 2 and related components are installed.

### System Requirements

- Ubuntu 22.04 (recommended) or 24.04
- At least 4 GB RAM
- USB serial port required for real hardware mode

### 0.1  Install ROS 2 Humble

```bash
# Set locale
sudo apt update && sudo apt install locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

# Add ROS 2 repository
sudo apt install software-properties-common
sudo add-apt-repository universe
sudo apt update && sudo apt install curl -y
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# Install ROS 2 Humble Desktop
sudo apt update
sudo apt install ros-humble-desktop
```

### 0.2  Install Build Tools & Dependencies

```bash
# colcon build tool
sudo apt install python3-colcon-common-extensions

# MoveIt 2
sudo apt install ros-humble-moveit

# ros2_control
sudo apt install ros-humble-ros2-control \
                 ros-humble-ros2-controllers \
                 ros-humble-controller-manager \
                 ros-humble-joint-state-publisher-gui
```

### 0.3  Set Environment Variables

```bash
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

### 0.4  Serial Port Permissions (Required for Real Hardware)

**Permanent setup (recommended)**:

```bash
sudo usermod -a -G dialout $USER
# Log out and back in for changes to take effect
```

**Temporary setup (repeat after each reboot)**:

```bash
sudo chmod 666 /dev/ttyACM0
```

---

## 1.  Installation — One Terminal

```bash
# Step 1  Create workspace
mkdir -p ~/so101_ws/src
cd ~/so101_ws/src

# Step 2  Place the source code
cp -r /path/to/SO-ARM101_ROS2 ./

# Step 3  Install system dependencies
cd ~/so101_ws
rosdep install --from-paths src --ignore-src -r -y

# Step 4  Build all packages
colcon build --symlink-install

# Step 5  Source the workspace  ← run this in every new terminal
source install/setup.bash
```

> **Real-hardware note** — The `so_arm_hardware` package is included.
> No external driver is needed. It communicates with STS3215 servos
> directly over serial using the SCS protocol.

---

## 2.  Visualisation Test

Best place to start — no controllers, no hardware.

```bash
#  Terminal 1
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_description view_description.launch.py rviz:=true
```

RViz opens with the full robot model. Drag the joint sliders to
verify the kinematics.

---

## 3.  Controller Test (Mock Mode)

Still no real robot required — everything runs in memory.

```bash
#  Terminal 1
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_description controllers_bringup.launch.py
```

Wait until the controllers appear as `active`:

```
joint_state_broadcaster      → active
joint_trajectory_controller  → active
```

> **Note** — Mock mode only spawns two controllers (`joint_state_broadcaster`
> and `joint_trajectory_controller`). The `gripper_controller` has been
> removed; the gripper is controlled by `joint_trajectory_controller` along
> with all 6 joints.

### What the controllers do

| Controller | Role |
|------------|------|
| `joint_state_broadcaster` | Publish joint states on `/joint_states` |
| `joint_trajectory_controller` | Execute waypoint trajectories on all 6 joints (arm + gripper) |

---

## 4.  MoveIt Motion Planning (Mock Hardware)

**One terminal is enough** — MoveIt launches the controller stack internally.

```bash
#  Terminal 1
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_moveit_config demo.launch.py
```

When the RViz window opens:
1. In the **MotionPlanning** panel, select **Planning Group → manipulator**
2. Set **Start State → `<current>`** and **Goal State → extended**
3. Click **Plan** then **Execute**

Pre-defined poses you can use as goals: `open`, `zero`, `extended`, `rest`.

### 4.1  MoveIt Interface Guide

After RViz launches, the **MotionPlanning** panel appears on the left with
the following tabs:

#### Planning Tab

| Control | Description |
|---------|-------------|
| **Planning Group** | Select `manipulator` (contains all 6 joints) |
| **Query Start State** | Start state, usually `<current>` |
| **Query Goal State** | Target state — choose a preset pose or set manually |
| **Plan** | Compute motion path only (orange trajectory preview) |
| **Execute** | Execute the planned path |
| **Plan & Execute** | One-click plan and execute |

#### Planning Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| **Planning Time (s)** | 5 | Maximum time per planning attempt |
| **Planning Attempts** | 10 | Maximum number of attempts |
| **Max Velocity Scaling** | 1.0 | Speed scaling (0.0–1.0) |
| **Max Acceleration Scaling** | 1.0 | Acceleration scaling (0.0–1.0) |

> **First test recommendation**: Set Velocity and Acceleration to 0.3
> to reduce movement speed for safety.

#### Scene Objects Tab

- Add obstacles (Box / Sphere / Cylinder) for collision detection
- Import / export scenes
- MoveIt will automatically avoid obstacles during planning

#### Stored States Tab

- Save frequently used arm poses
- Default poses: `open`, `zero`, `extended`, `rest`

### 4.2  Basic Operations

#### Method A: Interactive Dragging (Recommended)

1. Find the **interactive marker** (coloured arrows and rings) at the end
   of the arm in the 3D view
2. Drag arrows to translate, drag rings to rotate
3. The system solves IK automatically and updates joint angles in real time
4. Click **Plan** to see the planned trajectory (orange)
5. Click **Execute** when ready

> If dragging feels sluggish, try starting from the `rest` pose first.

#### Method B: Preset Poses

1. **Query Goal State** dropdown → select `open` / `extended` / `rest` etc.
2. Click **Update**
3. Click **Plan**
4. Click **Execute**

#### Method C: Manual Joint Angles

1. **Query Goal State** → **Joints** tab
2. Drag each joint slider to set target angles
3. Joint range reference:

   | Joint | Range (rad) |
   |-------|-------------|
   | shoulder_pan | -1.92 ~ 1.92 |
   | shoulder_lift | -1.75 ~ 1.75 |
   | elbow_flex | -1.69 ~ 1.54 |
   | wrist_flex | -1.60 ~ 1.60 |
   | wrist_roll | -2.30 ~ 2.30 |
   | gripper_joint | 0.00 ~ 1.70 |

4. Click **Update**
5. Click **Plan**
6. Click **Execute**

#### Method D: Random Valid Target

Click **Random Valid** to generate a reachable random pose, then Plan → Execute.

### 4.3  Safety Notes

1. **Reduce speed on first use**: Set Velocity / Acceleration to 0.1–0.3
2. **Emergency stop**: Press Ctrl+C anytime, or disconnect power
3. **Joint limits**: MoveIt will not plan beyond `joint_limits.yaml`, but
   ensure the config is correct
4. **Real hardware**: Ensure sufficient clearance around the arm before executing

### MoveIt Configuration Overview

| Item | Value |
|------|-------|
| Kinematic chain | `base_link` → `jaw_link` (6 joints: arm + gripper) |
| Joints | shoulder_pan, shoulder_lift, elbow_flex, wrist_flex, wrist_roll, gripper_joint |
| IK solver | KDL (timeout 100 ms, 5 attempts) |
| Default planner | RRTConnect (23 planners available) |
| Start tolerance | 0.3 rad — supports consecutive Plan+Execute |

---

## 5.  Gazebo Simulation

Gazebo requires **4 terminals running simultaneously**. Follow the steps
in order.

### 5.1  Launch Gazebo  (Terminal 1)

```bash
#  Terminal 1
source ~/so101_ws/install/setup.bash
ros2 launch so_arm_gz so_arm_gz_bringup.launch.py
```

Wait for the Gazebo window to appear; the robot drops briefly then settles.

### 5.2  Load the Trajectory Controller  (Terminal 2)

Gazebo starts with `forward_position_controller` active by default. You
must switch to `joint_trajectory_controller`:

```bash
#  Terminal 2
source ~/so101_ws/install/setup.bash

# Step A — deactivate forward_position_controller
ros2 control set_controller_state forward_position_controller inactive

# Step B — spawn (load + configure + activate) joint_trajectory_controller
ros2 run controller_manager spawner joint_trajectory_controller

# Step C — verify
ros2 control list_controllers
```

Expected output:

```
forward_position_controller  inactive
joint_state_broadcaster      active
joint_trajectory_controller  active
```

> Do **not** run `ros2 control load_controller` before spawning!
> It leaves the controller in `unconfigured` state and the spawner will
> fail to activate it. If you already did, `unload_controller` first.

### 5.3  Launch move_group  (Terminal 3)

```bash
#  Terminal 3
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_moveit_config move_group.launch.py use_sim_time:=True
```

### 5.4  Launch RViz  (Terminal 4)

```bash
#  Terminal 4
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_moveit_config moveit_rviz.launch.py
```

Once RViz is ready:
1. **Planning Group → manipulator**
2. **Goal State → open** (or `extended`, `rest`)
3. Click **Plan** then **Execute**

The arm joints in Gazebo will follow the motion.

> **Note** — Due to a `gz_ros2_control` Humble PID gain limitation,
> the gripper may not physically open in Gazebo (execution logs still
> report SUCCEEDED). Mock mode and real hardware are unaffected.

### 5.5  Headless Mode (no GUI)

```bash
ros2 launch so_arm_gz so_arm_gz_bringup.launch.py \
  gazebo_gui:=false \
  launch_rviz:=false
```

### 5.6  Troubleshooting: Repeated Load Failures

If the spawner keeps failing with `Failed to activate controller`,
fully reset with:

```bash
# 1. Unload the stuck controller
ros2 control unload_controller joint_trajectory_controller

# 2. Deactivate forward_position_controller
ros2 control set_controller_state forward_position_controller inactive

# 3. Re-spawn
ros2 run controller_manager spawner joint_trajectory_controller
```

---

## 6.  Real Hardware

Requires: SO-ARM101 arm assembled, servo driver board connected via USB.

### 6.1  Start Controllers (Can Skip)

```bash
#  Terminal 1
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_description controllers_bringup.launch.py \
  hardware_type:=real \
  usb_port:=/dev/ttyACM0
```

The `so_arm_hardware` plugin will:
1. Open the serial port
2. Scan for all 6 servo IDs (1–6)
3. Verify each servo responds
4. Enable torque and read current positions

Once the controllers are active, start MoveIt in two additional terminals:

```bash
#  Terminal 2 — move_group
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_moveit_config move_group.launch.py
```

```bash
#  Terminal 3 — RViz
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_moveit_config moveit_rviz.launch.py
```

### 6.2  MoveIt (One-Click Launch)

> The following command **replaces** section 6.1 (do not run both at the
> same time — stop the 6.1 process first). `demo.launch.py` includes the
> controller stack internally.

```bash
#  Terminal 1
source ~/so101_ws/install/setup.bash
ros2 launch so_arm101_moveit_config demo.launch.py \
  hardware_type:=real \
  usb_port:=/dev/ttyACM0
```

### 6.3  Troubleshooting Serial

| Symptom | Check |
|---------|-------|
| Port not found | `ls /dev/ttyACM* /dev/ttyUSB*` |
| Permission denied | `sudo chmod 666 /dev/ttyACM0` or add user to `dialout` |
| No servos detected | Verify power supply, check physical daisy-chain |

### 6.4  RViz Pose Mismatch

If the arm pose in RViz does not match the physical hardware (e.g. joint
offset, false collision warnings):

1. Ensure servo center calibration has been completed
2. Adjust `position_offset` for each joint in `so_arm101.ros2_control.xacro`
3. Formula: `new_offset = current_offset + (displayed_rad / 0.00153398)`
4. Rebuild the `so_arm101_description` package after changes

---

## 7.  FAQ

### Q1: Build fails with "package not found"

**A**: Ensure all system dependencies are installed and ROS 2 is sourced:

```bash
source /opt/ros/humble/setup.bash
cd ~/so101_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
```

### Q2: "Permission denied" when accessing serial port

**A**: Check serial port permissions:

```bash
# Temporary fix
sudo chmod 666 /dev/ttyACM0

# Permanent fix (requires logout)
sudo usermod -a -G dialout $USER
```

### Q3: MoveIt planning fails with "Motion planning start tree could not be initialized"

**A**: This usually has two causes:

1. **Joint out of bounds** — Check the `FixStartStateBounds` output in the
   logs. The current tolerance is 0.3 rad. If the error exceeds this,
   adjust `start_state_max_bounds_error` or check servo offsets.

2. **Start state collision** — Check the `FixStartStateCollision` output.
   If "Unable to find a valid state nearby", the current pose has a
   self-collision. The arm may be in a folded pose (e.g. gripper hitting
   the shoulder) or the offsets are incorrect. Adjust `position_offset`
   and try again.

### Q4: Execute succeeds but the arm does not move

**A**: Check controller status:

```bash
ros2 control list_controllers
```

Ensure `joint_trajectory_controller` is `active`. If not, re-spawn:

```bash
ros2 run controller_manager spawner joint_trajectory_controller
```

### Q5: RViz starts slowly or appears stuck

**A**: This is normal. MoveIt loads the URDF model, collision detection
plugins, IK solvers, etc. on startup. First launch takes about 10 seconds.

### Q6: Planned paths are jerky or unsmooth

**A**: Try the following:

- Switch to a different planner (select `RRTConnect` from the Planner dropdown)
- Increase Planning Time to 10 seconds
- Ensure the target is within the workspace (use `Random Valid` to test)

### Q7: Gripper does not move in Gazebo

**A**: This is a `gz_ros2_control` Humble PID gain limitation (fixed at
0.1, cannot be overridden via URDF parameters). The execution logs still
report SUCCEEDED, but the gripper won't physically open in Gazebo.
Mock mode and real hardware are unaffected.

---

## Reference: Launch Arguments

### `controllers_bringup.launch.py`

| Argument | Default | Options |
|----------|---------|---------|
| `hardware_type` | `mock_components` | `mock_components` / `real` / `gazebo` / `mujoco` |
| `usb_port` | `/dev/LeRobotFollower` | e.g. `/dev/ttyACM0` |
| `namespace` | `""` | Controller namespace |
| `use_namespace` | `false` | Enable namespace mode |

### `so_arm_gz_bringup.launch.py`

| Argument | Default | Description |
|----------|---------|-------------|
| `arm_id` | `so_arm101` | Arm variant |
| `gazebo_gui` | `true` | Show Gazebo window |
| `launch_rviz` | `true` | Show RViz (basic view) |
| `x / y / z` | `0.0 / -0.488 / 0.845` | Spawn position (m) |
| `roll / pitch / yaw` | `0 / 0 / -3.141` | Spawn orientation (rad) |
| `prefix` | `""` | Joint name prefix (multi-arm) |
| `namespace` | `""` | Controller namespace |

---

## Directory Layout

```
SO-ARM101_ROS2/
├── so_arm_utils/                   # Python helpers
├── so_arm101_description/          # URDF · controllers · meshes · RViz · MuJoCo
├── so_arm101_moveit_config/        # MoveIt 2 SRDF · planners · launch
├── so_arm_gz/                      # Gazebo simulation launcher
├── so_arm_hardware/                # Built-in SCS serial driver (C++)
└── Simulation/                     # Original CAD URDF (reference)
```

---

## References

- [ROS 2 Documentation](https://docs.ros.org/en/humble/)
- [MoveIt 2 Documentation](https://moveit.picknik.ai/humble/index.html)
- [SO-ARM100 Project](https://github.com/TheRobotStudio/SO-ARM100)

---

## License

Apache-2.0. STL meshes originate from the [SO-ARM100](https://github.com/TheRobotStudio/SO-ARM100)
repository and retain their original license terms.
