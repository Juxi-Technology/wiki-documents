"""
Shared definitions and robot metadata for SO-ARM ROS 2 packages.

Provides hardcoded filenames expected by MoveIt and a factory that
resolves package paths at runtime based on the robot identifier.
"""

import pathlib
from typing import Final, Literal

from ament_index_python.packages import get_package_share_directory


FILENAME_KINEMATICS: Final = "kinematics.yaml"
FILENAME_JOINT_LIMITS: Final = "joint_limits.yaml"
FILENAME_TRAJECTORY: Final = "trajectory_execution.yaml"
MOVEIT_CPP_FILENAME: Final = "moveit_cpp.yaml"

OMPL_PLANNING_PIPELINES: Final = ["ompl"]
DEFAULT_PIPELINE: Final = OMPL_PLANNING_PIPELINES[0]

RobotIdentifier = Literal["so_arm100", "so_arm101"]


class RobotPaths:
    """Holds canonical paths for a given robot's description and MoveIt packages.

    Instantiated via :func:`resolve_robot_paths` rather than directly.
    """

    __slots__ = (
        "robot",
        "desc_pkg",
        "moveit_pkg",
        "urdf_rel",
        "srdf_rel",
        "desc_share",
    )

    def __init__(self, robot_id: RobotIdentifier) -> None:
        desc = f"{robot_id}_description"
        self.robot: str = robot_id
        self.desc_pkg: str = desc
        self.moveit_pkg: str = f"{robot_id}_moveit_config"
        self.urdf_rel: str = f"{robot_id}.urdf.xacro"
        self.srdf_rel: str = f"{robot_id}.srdf"
        self.desc_share: pathlib.Path = pathlib.Path(
            get_package_share_directory(desc)
        )


def resolve_robot_paths(robot_id: RobotIdentifier) -> RobotPaths:
    """Build a RobotPaths instance for *robot_id*."""
    return RobotPaths(robot_id)
