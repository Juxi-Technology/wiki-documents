"""
Launch helpers and MoveIt configuration aggregator for SO-ARM robots.

Avoids repeating boilerplate across the description / moveit_config / gz packages.
"""

import pathlib
from copy import deepcopy
from dataclasses import dataclass, field
from functools import wraps
from pathlib import Path
from typing import Any

import xacro
import yaml
from ament_index_python.packages import get_package_share_directory
from launch.actions import OpaqueFunction
from launch.launch_context import LaunchContext

from so_arm_utils.constants import (
    DEFAULT_PIPELINE,
    FILENAME_JOINT_LIMITS,
    FILENAME_KINEMATICS,
    FILENAME_TRAJECTORY,
    MOVEIT_CPP_FILENAME,
    OMPL_PLANNING_PIPELINES,
    RobotIdentifier,
    resolve_robot_paths,
)


# ---------------------------------------------------------------------------
# Low-level file helpers
# ---------------------------------------------------------------------------

def read_yaml_file(path: Path) -> dict | None:
    """Return the parsed content of *path* as a dict, or None on error."""
    try:
        with path.open("r") as fh:
            content = yaml.safe_load(fh)
        return content
    except (FileNotFoundError, OSError):
        return None


def render_xacro(path: Path, substitutions: dict | None = None) -> str:
    """Process an xacro file and return the resulting XML string."""
    doc = xacro.process_file(
        str(path),
        mappings=deepcopy(substitutions) if substitutions else {},
    )
    return doc.toxml()


# ---------------------------------------------------------------------------
# Launch-decorator for typed configuration args
# ---------------------------------------------------------------------------

def with_launch_args(func):
    """Decorator that feeds launch configurations as a frozen dataclass."""

    def _bind(context: LaunchContext, *_args, **_kwargs):
        from dataclasses import make_dataclass

        Config = make_dataclass(
            "Config",
            list(context.launch_configurations.keys()),
            slots=True,
            frozen=True,
        )
        return func(Config(**context.launch_configurations))

    @wraps(func)
    def _outer(*_a, **_kw):
        return [OpaqueFunction(function=_bind)]

    return _outer


# ---------------------------------------------------------------------------
# MoveIt configuration aggregator
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class MoveItSettings:
    """Collects every parameter MoveIt needs from the robot's config packages."""

    robot_id: RobotIdentifier
    urdf_mappings: dict | None = None

    # -- output containers --
    urdf: dict = field(default_factory=dict, init=False)
    srdf: dict = field(default_factory=dict, init=False)
    kinematics: dict = field(default_factory=dict, init=False)
    pipelines: dict = field(default_factory=dict, init=False)
    trajectory: dict = field(default_factory=dict, init=False)
    scene_monitor: dict = field(default_factory=dict, init=False)
    extra_caps: dict = field(default_factory=dict, init=False)
    joint_limits: dict = field(default_factory=dict, init=False)
    moveit_cpp_config: dict = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        paths = resolve_robot_paths(self.robot_id)
        subs = self.urdf_mappings or {}

        # URDF / SRDF (xacro → string)
        self.urdf = {
            "robot_description": render_xacro(
                paths.desc_share / "urdf" / paths.urdf_rel, subs
            )
        }

        moveit_share = pathlib.Path(
            get_package_share_directory(paths.moveit_pkg)
        )
        self.srdf = {
            "robot_description_semantic": render_xacro(
                moveit_share / "config" / paths.srdf_rel, subs
            )
        }

        # IK solver settings
        self.kinematics = {
            "robot_description_kinematics": read_yaml_file(
                moveit_share / "config" / FILENAME_KINEMATICS
            ),
        }

        # Planning pipelines (all entries in one shared namespace)
        self.pipelines = {
            "planning_pipelines.pipeline_names": OMPL_PLANNING_PIPELINES,
            "default_planning_pipeline": DEFAULT_PIPELINE,
        }
        for name in OMPL_PLANNING_PIPELINES:
            yaml_path = moveit_share / "config" / f"{name}_planning.yaml"
            self.pipelines[name] = read_yaml_file(yaml_path)

        # Trajectory execution + controller setup
        self.trajectory = read_yaml_file(
            moveit_share / "config" / FILENAME_TRAJECTORY
        )

        # Planning scene monitor defaults
        self.scene_monitor = {
            "publish_planning_scene": True,
            "publish_geometry_updates": True,
            "publish_state_updates": True,
            "publish_transforms_updates": True,
        }

        # Planning-time joint overrides
        self.joint_limits = {
            "robot_description_planning": read_yaml_file(
                moveit_share / "config" / FILENAME_JOINT_LIMITS
            ),
        }

        # MoveItCpp helper params
        self.moveit_cpp_config = read_yaml_file(
            moveit_share / "config" / MOVEIT_CPP_FILENAME
        )

    def as_param_dict(self) -> dict[str, Any]:
        """Flatten every section into a single ROS parameter dictionary."""
        return (
            self.urdf
            | self.srdf
            | self.kinematics
            | self.pipelines
            | self.trajectory
            | self.scene_monitor
            | self.joint_limits
            | self.moveit_cpp_config
            | self.extra_caps
        )
