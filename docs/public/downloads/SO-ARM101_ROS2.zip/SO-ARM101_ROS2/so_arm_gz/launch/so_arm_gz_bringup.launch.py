"""
Complete Gazebo simulation environment for SO-ARM robotic arms.

Brings up Gazebo Sim (Bullet physics), spawns the robot from its xacro model,
wires up ros2_control, and optionally opens RViz.

Quick starts:
    ros2 launch so_arm_gz so_arm_gz_bringup.launch.py
    ros2 launch so_arm_gz so_arm_gz_bringup.launch.py arm_id:=so_arm101 gazebo_gui:=false
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    OpaqueFunction,
    RegisterEventHandler,
)
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
)
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare
from nav2_common.launch import ReplaceString, RewrittenYaml


def launch_setup(context, *args, **kwargs):
    """Build all nodes inside an OpaqueFunction so substitutions resolve."""

    # ── resolve basic flags ──
    arm_id_str = LaunchConfiguration("arm_id").perform(context)
    desc_pkg = f"{arm_id_str}_description"

    activate = LaunchConfiguration("activate_joint_controller").perform(context) == "true"
    show_rviz = LaunchConfiguration("launch_rviz").perform(context) == "true"
    show_gz_gui = LaunchConfiguration("gazebo_gui").perform(context) == "true"
    ns_enabled = LaunchConfiguration("use_namespace").perform(context) == "true"
    ns_val = LaunchConfiguration("namespace").perform(context)

    # ── file paths (resolved at Python time via ament) ──
    ctrl_yaml = LaunchConfiguration("controllers_file").perform(context) or ""
    if not ctrl_yaml:
        ctrl_yaml = os.path.join(
            get_package_share_directory(desc_pkg),
            "control", "ros2_controllers.yaml",
        )

    desc_xacro = LaunchConfiguration("description_file").perform(context) or ""
    if not desc_xacro:
        desc_xacro = os.path.join(
            get_package_share_directory(desc_pkg),
            "urdf", f"{arm_id_str}.urdf.xacro",
        )

    rviz_cfg = LaunchConfiguration("rviz_config_file").perform(context) or ""
    if not rviz_cfg:
        rviz_cfg = os.path.join(
            get_package_share_directory(desc_pkg),
            "rviz", "config.rviz",
        )

    # ── namespace-aware YAML ──
    ns_prefix = f"{ns_val}/" if ns_enabled and ns_val else ""
    raw_yaml = ReplaceString(
        source_file=ctrl_yaml,
        replacements={"<robot_namespace>": ns_prefix},
    )
    final_yaml = RewrittenYaml(
        source_file=raw_yaml,
        root_key=ns_val if ns_enabled else "",
        param_rewrites={},
        convert_types=True,
    )

    # ── compile URDF via xacro ──
    urdf_cmd = Command(
        [
            PathJoinSubstitution([FindExecutable(name="xacro")]),
            " ",
            desc_xacro,
            " simulation_controllers:=",
            final_yaml,
            " ros_namespace:=",
            ns_val,
            " ros2_control_hardware_type:=gazebo",
            " prefix:=",
            LaunchConfiguration("prefix"),
            " x:=",
            LaunchConfiguration("x"),
            " y:=",
            LaunchConfiguration("y"),
            " z:=",
            LaunchConfiguration("z"),
            " roll:=",
            LaunchConfiguration("roll"),
            " pitch:=",
            LaunchConfiguration("pitch"),
            " yaw:=",
            LaunchConfiguration("yaw"),
        ]
    )

    # ── nodes ──
    rsp = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        namespace=ns_val,
        output="both",
        parameters=[
            {
                "use_sim_time": True,
                "robot_description": ParameterValue(urdf_cmd, value_type=str),
            }
        ],
    )

    jsb = Node(
        package="controller_manager",
        executable="spawner",
        namespace=ns_val,
        arguments=["joint_state_broadcaster"],
        parameters=[{"use_sim_time": True}],
    )

    initial_ctrl = LaunchConfiguration("initial_joint_controller")

    jtc = Node(
        package="controller_manager",
        executable="spawner",
        namespace=ns_val,
        arguments=[initial_ctrl],
        parameters=[{"use_sim_time": True}],
        condition=IfCondition(LaunchConfiguration("activate_joint_controller")),
    )
    jtc_stopped = Node(
        package="controller_manager",
        executable="spawner",
        namespace=ns_val,
        arguments=[initial_ctrl, "--stopped"],
        parameters=[{"use_sim_time": True}],
        condition=UnlessCondition(LaunchConfiguration("activate_joint_controller")),
    )

    _rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="log",
        arguments=["-d", rviz_cfg],
    )
    rviz_delayed = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=jsb,
            on_exit=[_rviz_node],
        ),
        condition=IfCondition(LaunchConfiguration("launch_rviz")),
    )

    spawn = Node(
        package="ros_gz_sim",
        executable="create",
        output="screen",
        arguments=["-string", urdf_cmd, "-name", arm_id_str, "-allow_renaming", "true"],
    )

    gz_args = " -r -v 4 empty.sdf"
    if not show_gz_gui:
        gz_args = " -s" + gz_args
    gz_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [FindPackageShare("ros_gz_sim"), "/launch/gz_sim.launch.py"]
        ),
        launch_arguments={"gz_args": gz_args}.items(),
    )

    bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        arguments=["/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock"],
        output="screen",
    )

    return [rsp, jsb, jtc, jtc_stopped, rviz_delayed, spawn, gz_launch, bridge]


def generate_launch_description() -> LaunchDescription:
    args = [
        DeclareLaunchArgument("arm_id", default_value="so_arm101",
                              choices=["so_arm100", "so_arm101"]),
        DeclareLaunchArgument("controllers_file", default_value=""),
        DeclareLaunchArgument("prefix", default_value='""'),
        DeclareLaunchArgument("use_namespace", default_value="false"),
        DeclareLaunchArgument("namespace", default_value=""),
        DeclareLaunchArgument("activate_joint_controller", default_value="true"),
        DeclareLaunchArgument("initial_joint_controller",
                              default_value="forward_position_controller"),
        DeclareLaunchArgument("description_file", default_value=""),
        DeclareLaunchArgument("launch_rviz", default_value="true"),
        DeclareLaunchArgument("rviz_config_file", default_value=""),
        DeclareLaunchArgument("gazebo_gui", default_value="true"),
        DeclareLaunchArgument("x", default_value="0.0"),
        DeclareLaunchArgument("y", default_value="-0.488"),
        DeclareLaunchArgument("z", default_value="0.845"),
        DeclareLaunchArgument("roll", default_value="0.0"),
        DeclareLaunchArgument("pitch", default_value="0.0"),
        DeclareLaunchArgument("yaw", default_value="-3.141"),
    ]
    return LaunchDescription(args + [OpaqueFunction(function=launch_setup)])
