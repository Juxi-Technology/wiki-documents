"""
Start ros2_control infrastructure for SO-ARM101.

Spawns the controller_manager along with three default controllers
(joint_state_broadcaster, joint_trajectory_controller, gripper_controller).
Supports mock, real-hardware, gazebo, and mujoco back-ends.

Usage:
    ros2 launch so_arm101_description controllers_bringup.launch.py
    ros2 launch so_arm101_description controllers_bringup.launch.py hardware_type:=real
"""

import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.descriptions import ParameterFile
from nav2_common.launch import ReplaceString, RewrittenYaml

from so_arm_utils.launch_utils import render_xacro, with_launch_args

PACKAGE = "so_arm101_description"
ACTIVE_CONTROLLERS = [
    "joint_state_broadcaster",
    "joint_trajectory_controller",
]


# ── helpers ──────────────────────────────────────────────────────────────

def _trailing_slash(text: str) -> str:
    """Return *text* with a trailing '/' if non-empty, else ''."""
    s = text.strip()
    return f"{s}/" if s else ""


@with_launch_args
def _publisher_node(cfg):
    """Build the robot_state_publisher node with rendered xacro."""
    from ament_index_python.packages import get_package_share_path

    ns = _trailing_slash(cfg.namespace)
    urdf_str = render_xacro(
        get_package_share_path(PACKAGE) / "urdf" / "so_arm101.urdf.xacro",
        {
            "prefix": ns,
            "ros2_control_file": cfg.ros2_control_xacro_file,
            "ros2_control_hardware_type": cfg.hardware_type,
            "usb_port": cfg.usb_port,
        },
    )
    return [
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            namespace=ns,
            parameters=[{"robot_description": urdf_str}],
        ),
    ]


def _make_spawner(ctrl_name: str, ns_cfg: LaunchConfiguration) -> Node:
    """Return a controller_manager spawner for *ctrl_name*."""
    return Node(
        package="controller_manager",
        executable="spawner",
        namespace=ns_cfg,
        arguments=[ctrl_name, "--controller-manager-timeout", "30"],
    )


# ── launch description ───────────────────────────────────────────────────

def generate_launch_description() -> LaunchDescription:
    # Package-relative directory for default file paths
    pkg_root = os.path.join(os.path.dirname(__file__), "..")

    # ── arguments ──
    declared = [
        DeclareLaunchArgument(
            "hardware_type",
            default_value="mock_components",
            description="Backend: mock_components | real | gazebo | mujoco",
        ),
        DeclareLaunchArgument(
            "usb_port",
            default_value="/dev/LeRobotFollower",
            description="Serial device (real hardware only)",
        ),
        DeclareLaunchArgument(
            "use_namespace",
            default_value="false",
            description="Apply namespace to controller stack",
        ),
        DeclareLaunchArgument(
            "namespace",
            default_value="",
            description="Controller manager namespace",
        ),
        DeclareLaunchArgument(
            "ros2_control_xacro_file",
            default_value=os.path.join(
                pkg_root, "control", "so_arm101.ros2_control.xacro"
            ),
        ),
        DeclareLaunchArgument(
            "controller_config_file",
            default_value=os.path.join(pkg_root, "control", "ros2_controllers.yaml"),
        ),
    ]

    # ── substitutions ──
    hw_type = LaunchConfiguration("hardware_type")
    ns_key = LaunchConfiguration("namespace")
    use_ns = LaunchConfiguration("use_namespace")
    yaml_file = LaunchConfiguration("controller_config_file")

    # Conditionally replace <robot_namespace> placeholder
    yaml_processed = ReplaceString(
        source_file=yaml_file,
        replacements={"<robot_namespace>": (ns_key, "/")},
        condition=IfCondition(use_ns),
    )
    yaml_processed = ReplaceString(
        source_file=yaml_file,
        replacements={"<robot_namespace>": ""},
        condition=UnlessCondition(use_ns),
    )

    namespaced_yaml = ParameterFile(
        RewrittenYaml(
            source_file=yaml_processed,
            root_key=ns_key,
            param_rewrites={},
            convert_types=True,
        ),
        allow_substs=True,
    )

    # ── nodes ──
    is_sim = PythonExpression(["'", hw_type, "' == 'mujoco'"])
    manager = Node(
        package="controller_manager",
        executable="ros2_control_node",
        namespace=ns_key,
        parameters=[{"use_sim_time": is_sim}, namespaced_yaml],
        remappings=[("~/robot_description", "/robot_description")],
        output="screen",
        emulate_tty=True,
    )

    spawners = [_make_spawner(c, ns_key) for c in ACTIVE_CONTROLLERS]
    delayed_spawners = TimerAction(period=2.0, actions=spawners)

    return LaunchDescription(
        declared + [manager] + _publisher_node() + [delayed_spawners]
    )
