"""
Standalone visualisation of the SO-ARM101 URDF model in RViz.

Starts robot_state_publisher (xacro → URDF), an optional joint_state_publisher_gui
for manual pose tweaking, and optionally RViz with a preconfigured view.

Examples:
    ros2 launch so_arm101_description view_description.launch.py
    ros2 launch so_arm101_description view_description.launch.py rviz:=true
    ros2 launch so_arm101_description view_description.launch.py joint_state_publisher:=false
"""

import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch.substitutions import FindExecutable
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare

PACKAGE_NAME = "so_arm101_description"


def _build_robot_model_xml() -> Command:
    """Execute xacro and return the processed URDF string."""
    return Command(
        [
            PathJoinSubstitution([FindExecutable(name="xacro")]),
            " ",
            PathJoinSubstitution(
                [FindPackageShare(PACKAGE_NAME), "urdf", "so_arm101.urdf.xacro"]
            ),
        ]
    )


def generate_launch_description() -> LaunchDescription:
    show_rviz = LaunchConfiguration("rviz")
    show_gui = LaunchConfiguration("joint_state_publisher")

    # -- Nodes --
    publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="both",
        parameters=[
            {
                "robot_description": ParameterValue(
                    _build_robot_model_xml(), value_type=str
                )
            }
        ],
    )

    joint_gui = Node(
        package="joint_state_publisher_gui",
        executable="joint_state_publisher_gui",
        name="joint_state_publisher_gui",
        condition=IfCondition(show_gui),
    )

    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        arguments=[
            "-d",
            os.path.join(
                FindPackageShare(PACKAGE_NAME).find(PACKAGE_NAME),
                "rviz",
                "config.rviz",
            ),
        ],
        condition=IfCondition(show_rviz),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("rviz", default_value="false", description="Open RViz"),
            DeclareLaunchArgument(
                "joint_state_publisher",
                default_value="true",
                description="Run joint_state_publisher_gui",
            ),
            publisher,
            joint_gui,
            rviz_node,
        ]
    )
