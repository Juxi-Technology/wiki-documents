"""
Full demo for SO-ARM101: controllers + MoveIt + RViz.

Launches the low-level controller stack, the MoveIt move_group node,
and RViz with the MoveIt planning panel. Hardware type controls whether
mock components, real hardware, gazebo, or mujoco is used.

Usage:
    ros2 launch so_arm101_moveit_config demo.launch.py
    ros2 launch so_arm101_moveit_config demo.launch.py hardware_type:=gazebo
"""

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import AnyLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from ament_index_python.packages import get_package_share_directory

ROBOT = "so_arm101"
DESC_PKG = f"{ROBOT}_description"
MOVEIT_PKG = f"{ROBOT}_moveit_config"


def generate_launch_description() -> LaunchDescription:
    hw_arg = DeclareLaunchArgument("hardware_type", default_value="mock_components")
    hw_type = LaunchConfiguration("hardware_type")

    # 1. Controller infrastructure
    ctrl = IncludeLaunchDescription(
        AnyLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory(DESC_PKG),
                "launch",
                "controllers_bringup.launch.py",
            )
        ),
        launch_arguments={"hardware_type": hw_type}.items(),
    )

    # 2. RViz with MoveIt panel
    rviz = IncludeLaunchDescription(
        AnyLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory(MOVEIT_PKG),
                "launch",
                "moveit_rviz.launch.py",
            )
        ),
    )

    # 3. MoveIt move_group node
    is_sim = PythonExpression(["'", hw_type, "' in ('gazebo', 'mujoco')"])
    moveit = IncludeLaunchDescription(
        AnyLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory(MOVEIT_PKG),
                "launch",
                "move_group.launch.py",
            )
        ),
        launch_arguments={"use_sim_time": is_sim}.items(),
    )

    return LaunchDescription([hw_arg, ctrl, rviz, moveit])
