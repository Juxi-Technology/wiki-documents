"""
Launch RViz preconfigured with the MoveIt planning panel for SO-ARM101.

Passes robot_description, srdf, kinematics, and joint limits so the
MoveIt RViz plugin can display the robot and offer interactive planning.

Usage:
    ros2 launch so_arm101_moveit_config moveit_rviz.launch.py
    ros2 launch so_arm101_moveit_config moveit_rviz.launch.py rviz_config:=other.rviz
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

from so_arm_utils.launch_utils import MoveItSettings

MOVEIT_PKG = "so_arm101_moveit_config"


def generate_launch_description() -> LaunchDescription:
    settings = MoveItSettings(robot_id="so_arm101")

    rviz_config_arg = DeclareLaunchArgument(
        "rviz_config", default_value="move_group.rviz"
    )

    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        arguments=[
            "-d",
            PathJoinSubstitution(
                [FindPackageShare(MOVEIT_PKG), "rviz", LaunchConfiguration("rviz_config")]
            ),
        ],
        parameters=[
            settings.joint_limits,
            settings.urdf,
            settings.srdf,
            settings.kinematics,
            settings.pipelines,
        ],
    )

    return LaunchDescription([rviz_config_arg, rviz_node])
