"""
Launch the MoveIt 2 move_group node for SO-ARM101.

The node loads urdf, srdf, kinematics, planning pipelines, joint limits,
and controller configuration from the description and moveit_config packages.

Usage:
    ros2 launch so_arm101_moveit_config move_group.launch.py
    ros2 launch so_arm101_moveit_config move_group.launch.py use_sim_time:=True
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

from so_arm_utils.launch_utils import MoveItSettings


def generate_launch_description() -> LaunchDescription:
    sim_time_arg = DeclareLaunchArgument(
        "use_sim_time",
        default_value="False",
        description="Set use_sim_time for move_group",
    )

    settings = MoveItSettings(robot_id="so_arm101")

    group = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        parameters=[
            settings.as_param_dict(),
            {"use_sim_time": LaunchConfiguration("use_sim_time")},
        ],
    )

    return LaunchDescription([sim_time_arg, group])
