
# 2-DOF Camera Gimbal

A 2-degree-of-freedom camera gimbal control project with automatic tracking for color, face, and QR code targets.

---

## 📋 Features

- 🎮 Keyboard manual control for gimbal
- 🎯 Color object auto tracking
- 👤 Face auto tracking
- 📱 QR code auto tracking
- 🔒 Target locking mechanism
- 🚀 Quick startup (using DSHOW backend)

---

## 🛠 Hardware Configurations

- **Servo Model**: SCS009
- **Servo Assignment**:
  - Servo #1: Left/right rotation control
  - Servo #2: Tilt up/down control
- **Communication Type**: Serial bus driver board
- **Driver Board Chip**: CH343
- **Baud Rate**: Default 1Mbps

### Servo Parameters

| Parameter | Servo #1 (Left/Right) | Servo #2 (Up/Down) |
|-----------|------------------------|-----------------------|
| Range | 220-802 | 220-511 |
| Center | 511 | 511 |
| Note | 220=Left, 802=Right | 220=Up, 511=Center |

---

## 📁 Project Structure

```
2-DOF-Camera-Gimbal/
├── docs/            # Documentation and tutorials
│   └── tutorials/  # Tutorial files
├── examples/        # Example programs
│   ├── auto_tracking_demo.py  # Full tracking demo
│   ├── basic_usage.py        # Basic usage examples
│   ├── keyboard_control.py    # Keyboard control examples
│   └── diagnostic.py         # Diagnostic tools
├── src/            # Source code
│   ├── detectors/  # Target detectors
│   │   ├── color_detector.py
│   │   ├── face_detector.py
│   │   └── qr_detector.py
│   ├── trackers/  # Tracking controllers
│   │   └── tracking_controller.py
│   └── sc_servo.py  # Servo communication library
├── .gitignore
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Find Available Devices

**Find Available Cameras**
```bash
python examples/list_cameras.py
```

**Find Available Serial Ports**
```bash
python examples/list_ports.py
```

### 3. Run the Demo

Configure with command line arguments:
```bash
python examples/auto_tracking_demo.py --camera 0 --port COM3 --color red
```

**Parameter Descriptions**
- `--camera` or `-c`: Camera index (default 0)
- `--port` or `-p`: Serial port device (default COM3)
- `--color` or `-C`: Default color (default red)

---

## 🎮 Usage Instructions

### Hotkeys

| Key | Function Description |
|------|----------------|
| `1` | Switch to face tracking mode |
| `2` | Switch to color tracking mode |
| `C` | Connect gimbal |
| `R` | Return to center |
| `T` | Lock/start tracking target |
| `S` | Stop tracking |
| `X` | Color mode: Red |
| `Y` | Color mode: Green |
| `Z` | Color mode: Blue |
| `Q` | Exit program |

### Auto Tracking Usage Flow

1. Press `C` to connect the gimbal
2. Select mode (press `1` or `2`)
3. Move target object to center of frame
4. Press `T` to lock target
5. Move target, gimbal will auto follow

---

## 📚 Documentation and Tutorials

For detailed tutorials, check the [docs/tutorials/](docs/tutorials/) directory:

- English tutorials in [docs/tutorials/en/](docs/tutorials/en/):
  - [01-Quick-Start-Guide.md](docs/tutorials/en/01-Quick-Start-Guide.md) - Quick start guide
  - [02-Hardware-and-Environment.md](docs/tutorials/en/02-Hardware-and-Environment.md) - Hardware list and environment setup
  - [03-Basic-Usage.md](docs/tutorials/en/03-Basic-Usage.md) - Keyboard control and basic operation
  - [04-Advanced-Features-and-Tracking.md](docs/tutorials/en/04-Advanced-Features-and-Tracking.md) - Detailed tracking features
  - [05-Troubleshooting.md](docs/tutorials/en/05-Troubleshooting.md) - Common problems and solutions

- Chinese (Simplified) tutorials in [docs/tutorials/cn/](docs/tutorials/cn/):
  - [01-快速开始指南.md](docs/tutorials/cn/01-快速开始指南.md) - 快速开始指南
  - [02-硬件与环境准备.md](docs/tutorials/cn/02-硬件与环境准备.md) - 硬件清单和环境准备
  - [03-基础使用.md](docs/tutorials/cn/03-基础使用.md) - 键盘控制和基础使用
  - [04-高级功能与追踪.md](docs/tutorials/cn/04-高级功能与追踪.md) - 高级功能和追踪详解
  - [05-故障排除.md](docs/tutorials/cn/05-故障排除.md) - 常见问题和解决方法

- Chinese (Traditional) tutorials in [docs/tutorials/hk/](docs/tutorials/hk/):
  - [01-快速開始指南.md](docs/tutorials/hk/01-快速開始指南.md) - 快速开始指南
  - [02-硬件與環境準備.md](docs/tutorials/hk/02-硬件與環境準備.md) - 硬件清单和环境准备
  - [03-基礎使用.md](docs/tutorials/hk/03-基礎使用.md) - 键盘控制和基础使用
  - [04-高級功能與追蹤.md](docs/tutorials/hk/04-高級功能與追蹤.md) - 高级功能和追踪详解
  - [05-故障排除.md](docs/tutorials/hk/05-故障排除.md) - 常见问题和解决方法

---

## 🔧 Technical Notes

### Tracking Control Parameters

In `src/trackers/tracking_controller.py` you can adjust:

| Parameter | Default Value | Description |
|------------|----------------|----------------|
| `kp_pan` | 0.08 | Pan tracking proportional gain |
| `kp_tilt` | 0.12 | Tilt tracking proportional gain |
| `dead_zone` | 30 | Dead zone (pixels), no movement within this range |
| `min_move_interval` | 0.15 | Minimum move interval (seconds) |

### Target Locking Mechanism

After locking, the system selects targets based on:
- Closest to lock point (70% weight)
- Size most similar to locked size (30% weight)

---

## 📖 Servo Specifications

- **Model**: SCS009
- **Operating Voltage**: 4V-7.4V (typical 6V)
- **Stall Torque**: 2.3kg·cm at 6V
- **Protocol**: Half-duplex async serial (TTL)
