
import time
import collections


class TrackingController:
    def __init__(self, gimbal):
        self.gimbal = gimbal
        
        self.current_pan = 511
        self.current_tilt = 511
        
        self.kp_pan = 0.08
        self.kp_tilt = 0.12
        self.dead_zone = 30
        
        self.img_width = 640
        self.img_height = 480
        
        self.pan_min = 220
        self.pan_max = 802
        self.tilt_min = 220
        self.tilt_max = 511
        
        self.last_move_time = 0
        self.min_move_interval = 0.15
        self.last_print_time = 0
        
        self.x_history = collections.deque(maxlen=5)
        self.y_history = collections.deque(maxlen=5)
    
    def set_image_size(self, width, height):
        self.img_width = width
        self.img_height = height
    
    def add_to_history(self, x, y):
        self.x_history.append(x)
        self.y_history.append(y)
    
    def get_smoothed(self):
        if not self.x_history:
            return None
        return (
            sum(self.x_history) // len(self.x_history), 
            sum(self.y_history) // len(self.y_history)
        )
    
    def clear_history(self):
        self.x_history.clear()
        self.y_history.clear()
    
    def calculate_move(self, target_x, target_y):
        cx = self.img_width // 2
        cy = self.img_height // 2
        
        err_x = target_x - cx
        err_y = target_y - cy
        
        if abs(err_x) < self.dead_zone and abs(err_y) < self.dead_zone:
            return (0, 0)
        
        delta_pan = int(self.kp_pan * err_x)
        delta_tilt = int(self.kp_tilt * err_y)
        
        return (delta_pan, delta_tilt)
    
    def apply_move(self, delta_pan, delta_tilt):
        now = time.time()
        if now - self.last_move_time < self.min_move_interval:
            return
        
        new_pan = self.current_pan + delta_pan
        new_tilt = self.current_tilt + delta_tilt
        
        new_pan = max(self.pan_min, min(self.pan_max, new_pan))
        new_tilt = max(self.tilt_min, min(self.tilt_max, new_tilt))
        
        if new_pan != self.current_pan or new_tilt != self.current_tilt:
            print("Move gimbal: Pan", self.current_pan, "->", new_pan, "| Tilt", self.current_tilt, "->", new_tilt)
            try:
                self.gimbal.pan_to(new_pan, time_ms=350)
                self.gimbal.tilt_to(new_tilt, time_ms=350)
            except Exception as e:
                print("Gimbal move error:", str(e))
            self.current_pan = new_pan
            self.current_tilt = new_tilt
            self.last_move_time = now
    
    def update(self, target_x, target_y):
        now = time.time()
        self.add_to_history(target_x, target_y)
        smoothed = self.get_smoothed()
        
        if smoothed:
            sx, sy = smoothed
            cx = self.img_width // 2
            cy = self.img_height // 2
            err_x = sx - cx
            err_y = sy - cy
            
            if now - self.last_print_time > 0.3:
                print("Target: Raw(", target_x, target_y, ") Smoothed(", sx, sy, ") | Err(x:", err_x, "y:", err_y, ")")
                self.last_print_time = now
            
            delta_pan, delta_tilt = self.calculate_move(sx, sy)
            self.apply_move(delta_pan, delta_tilt)
    
    def return_to_center(self):
        self.clear_history()
        print("Returning gimbal to center...")
        try:
            self.gimbal.pan_to(511, time_ms=600)
            self.gimbal.tilt_to(511, time_ms=600)
        except Exception as e:
            print("Return to center error:", str(e))
        self.current_pan = 511
        self.current_tilt = 511
        time.sleep(0.4)
    
    def set_current_positions(self, pan, tilt):
        self.current_pan = pan
        self.current_tilt = tilt
