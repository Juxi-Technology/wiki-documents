
import cv2
import numpy as np
from .base_detector import BaseDetector


class ColorDetector(BaseDetector):
    COLOR_RANGES = {
        'red': [
            np.array([0, 120, 70]),
            np.array([10, 255, 255]),
            np.array([170, 120, 70]),
            np.array([180, 255, 255])
        ],
        'green': [
            np.array([40, 100, 70]),
            np.array([80, 255, 255])
        ],
        'blue': [
            np.array([100, 100, 70]),
            np.array([140, 255, 255])
        ],
        'yellow': [
            np.array([20, 100, 70]),
            np.array([40, 255, 255])
        ]
    }

    COLOR_BGR = {
        'red': (0, 0, 255),
        'green': (0, 255, 0),
        'blue': (255, 0, 0),
        'yellow': (0, 255, 255)
    }

    def __init__(self, target_color='red'):
        super().__init__()
        self.target_color = target_color.lower()

    def set_color(self, color):
        color_lower = color.lower()
        if color_lower in self.COLOR_RANGES:
            self.target_color = color_lower

    def detect(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = self._create_mask(hsv)
        mask = self._denoise_mask(mask)
        contours, _ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        result = {'center': None, 'size': 0, 'color': self.target_color, 'contours': []}
        
        if contours:
            valid_contours = []
            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area > 100:
                    M = cv2.moments(cnt)
                    if M['m00'] != 0:
                        cx = int(M['m10'] / M['m00'])
                        cy = int(M['m01'] / M['m00'])
                        x, y, w, h = cv2.boundingRect(cnt)
                        valid_contours.append({
                            'center': (cx, cy),
                            'size': area,
                            'box': (x, y, w, h)
                        })
            
            if valid_contours:
                valid_contours.sort(key=lambda c: c['size'], reverse=True)
                result['contours'] = valid_contours
                result['center'] = valid_contours[0]['center']
                result['size'] = valid_contours[0]['size']
                
                for i, cnt in enumerate(valid_contours):
                    x, y, w, h = cnt['box']
                    cx, cy = cnt['center']
                    color = self.COLOR_BGR[self.target_color] if i == 0 else (128, 128, 128)
                    cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                    cv2.circle(frame, (cx, cy), 7, (0, 0, 255) if i == 0 else (128, 128, 128), -1)
                    cv2.putText(frame, '#' + str(i), (x, y - 5),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        return frame, result

    def _create_mask(self, hsv):
        if self.target_color == 'red':
            lower1, upper1, lower2, upper2 = self.COLOR_RANGES['red']
            mask1 = cv2.inRange(hsv, lower1, upper1)
            mask2 = cv2.inRange(hsv, lower2, upper2)
            return cv2.bitwise_or(mask1, mask2)
        else:
            lower, upper = self.COLOR_RANGES[self.target_color]
            return cv2.inRange(hsv, lower, upper)

    def _denoise_mask(self, mask):
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=2)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        return mask

    def _draw_results(self, frame, x, y, w, h, cx, cy, result):
        color = self.COLOR_BGR[self.target_color]
        
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
        cv2.circle(frame, (cx, cy), 7, (0, 0, 255), -1)
        cv2.circle(frame, (cx, cy), 3, (255, 255, 255), -1)
        
        cv2.putText(frame, 'Color: ' + self.target_color, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        cv2.putText(frame, 'Center: (' + str(cx) + ', ' + str(cy) + ')', (10, 55),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        cv2.putText(frame, 'Size: ' + str(int(result['size'])), (10, 80),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        return frame

