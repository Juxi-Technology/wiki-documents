from .base_detector import BaseDetector
import cv2
try:
    from pyzbar import pyzbar
    PYZBAR_AVAILABLE = True
except ImportError:
    PYZBAR_AVAILABLE = False


class QRDetector(BaseDetector):
    def __init__(self):
        super().__init__()
        if not PYZBAR_AVAILABLE:
            raise ImportError('pyzbar library is required. Please install it with pip install pyzbar pillow')

    def detect(self, frame):
        results = []
        annotated_frame = frame.copy()

        if frame is None or len(frame) == 0:
            return annotated_frame, results

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        barcodes = pyzbar.decode(gray)

        for barcode in barcodes:
            if barcode.type == 'QRCODE':
                x, y, w, h = barcode.rect
                bbox = (x, y, w, h)
                data = barcode.data.decode('utf-8')

                results.append({
                    'data': data,
                    'bbox': bbox
                })

                cv2.rectangle(annotated_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(annotated_frame, data, (x, y - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        return annotated_frame, results
