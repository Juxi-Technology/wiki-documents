class BaseDetector:
    def __init__(self):
        pass

    def detect(self, frame):
        raise NotImplementedError('Subclasses must implement detect method')
