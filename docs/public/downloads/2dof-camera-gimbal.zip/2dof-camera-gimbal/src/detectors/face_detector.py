import cv2
from .base_detector import BaseDetector


class FaceDetector(BaseDetector):
    def __init__(self, confidence_threshold=0.7, scale_factor=1.1, min_neighbors=5):
        super().__init__()
        self.scale_factor = scale_factor
        self.min_neighbors = min_neighbors
        
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        if self.face_cascade.empty():
            raise Exception('Failed to load face cascade classifier')

    def detect(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray, 
            scaleFactor=self.scale_factor, 
            minNeighbors=self.min_neighbors,
            minSize=(30, 30)
        )
        
        result_frame = frame.copy()
        detections = []
        
        for (x, y, w, h) in faces:
            detections.append({
                'bbox': (x, y, w, h),
                'confidence': 1.0
            })
            cv2.rectangle(result_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(result_frame, 'Face', (x, y - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        return result_frame, detections
