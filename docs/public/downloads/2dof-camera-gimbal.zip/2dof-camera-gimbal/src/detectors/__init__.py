
from .base_detector import BaseDetector
from .color_detector import ColorDetector
from .face_detector import FaceDetector
from .qr_detector import QRDetector

__all__ = [
    'BaseDetector',
    'ColorDetector',
    'FaceDetector',
    'QRDetector'
]
