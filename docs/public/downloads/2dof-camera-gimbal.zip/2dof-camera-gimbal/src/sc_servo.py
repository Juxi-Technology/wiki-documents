
import serial
import time


class SCServo:
    """飞特SCS系列舵机驱动"""
    
    FRAME_HEADER = 0xFF
    DEFAULT_BAUDRATE = 1000000
    
    # 指令
    CMD_READ = 0x02
    CMD_WRITE = 0x03
    
    # 寄存器地址
    REG_TORQUE_ENABLE = 40
    REG_GOAL_POSITION = 42
    REG_GOAL_TIME = 44
    REG_GOAL_SPEED = 46
    REG_PRESENT_POSITION = 56
    REG_PRESENT_VOLTAGE = 62
    REG_PRESENT_TEMPERATURE = 63
    
    def __init__(self, port, baudrate=DEFAULT_BAUDRATE, timeout=0.1):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.serial = None
    
    def connect(self):
        """连接串口"""
        try:
            self.serial = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=self.timeout
            )
            return True
        except Exception as e:
            print(f"连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开串口"""
        if self.serial and self.serial.is_open:
            self.serial.close()
            return True
        return False
    
    def _checksum(self, data):
        """计算校验和"""
        checksum = sum(data)
        checksum = (~checksum) & 0xFF
        return checksum
    
    def _send_packet(self, packet):
        """发送数据包并接收回应"""
        if not self.serial or not self.serial.is_open:
            return None
        
        self.serial.reset_input_buffer()
        self.serial.write(bytearray(packet))
        self.serial.flush()
        time.sleep(0.01)
        
        return self._receive_packet()
    
    def _receive_packet(self):
        """接收并解析数据包"""
        if not self.serial or not self.serial.is_open:
            return None
        
        start_time = time.time()
        response_bytes = []
        
        # 先读取所有可用数据
        while time.time() - start_time < self.timeout:
            if self.serial.in_waiting > 0:
                response_bytes.extend(self.serial.read(self.serial.in_waiting))
            else:
                time.sleep(0.005)
            if len(response_bytes) >= 4:
                break
        
        if len(response_bytes) < 5:
            return None
        
        # 查找帧头
        for i in range(len(response_bytes) - 4):
            if response_bytes[i] == self.FRAME_HEADER and response_bytes[i+1] == self.FRAME_HEADER:
                servo_id = response_bytes[i+2]
                length = response_bytes[i+3]
                
                if len(response_bytes) >= i + 4 + length + 1:
                    data_end = i + 4 + length
                    data = response_bytes[i+4 : data_end]
                    checksum = response_bytes[data_end]
                    
                    # 验证校验和
                    payload = [servo_id, length] + data
                    if self._checksum(payload) == checksum:
                        return {
                            'id': servo_id,
                            'data': data
                        }
        
        return None
    
    def write_data(self, servo_id, reg, values):
        """写数据到寄存器"""
        length = len(values) + 3
        packet = [
            self.FRAME_HEADER, self.FRAME_HEADER,
            servo_id,
            length,
            self.CMD_WRITE,
            reg
        ] + values
        packet.append(self._checksum(packet[2:]))
        return self._send_packet(packet)
    
    def read_data(self, servo_id, reg, read_len):
        """从寄存器读数据"""
        length = 4
        packet = [
            self.FRAME_HEADER, self.FRAME_HEADER,
            servo_id,
            length,
            self.CMD_READ,
            reg,
            read_len
        ]
        packet.append(self._checksum(packet[2:]))
        return self._send_packet(packet)
    
    def enable_torque(self, servo_id, enable=True):
        """使能或禁用扭矩"""
        return self.write_data(servo_id, self.REG_TORQUE_ENABLE, [1 if enable else 0])
    
    def set_position(self, servo_id, position, time_ms=None, speed=None):
        """
        设置位置 (字节序: [高字节, 低字节])
        
        参数:
        position: 目标位置
        time_ms: 到达目标位置的时间（毫秒）
        speed: 运动速度
        """
        pos_low = position & 0xFF
        pos_high = (position >> 8) & 0xFF
        
        values = [pos_high, pos_low]
        
        if time_ms is not None:
            time_low = time_ms & 0xFF
            time_high = (time_ms >> 8) & 0xFF
            values.extend([time_high, time_low])
            
            if speed is not None:
                speed_low = speed & 0xFF
                speed_high = (speed >> 8) & 0xFF
                values.extend([speed_high, speed_low])
        
        return self.write_data(servo_id, self.REG_GOAL_POSITION, values)
    
    def get_position(self, servo_id):
        """读取当前位置 (字节序: [高字节, 低字节])"""
        resp = self.read_data(servo_id, self.REG_PRESENT_POSITION, 2)
        if resp and len(resp['data']) >= 3:
            b1 = resp['data'][1]
            b0 = resp['data'][2]
            return (b1 << 8) | b0
        return None
    
    def get_voltage(self, servo_id):
        """读取电压"""
        resp = self.read_data(servo_id, self.REG_PRESENT_VOLTAGE, 1)
        if resp and len(resp['data']) >= 2:
            return resp['data'][1] / 10.0
        return None
    
    def get_temperature(self, servo_id):
        """读取温度"""
        resp = self.read_data(servo_id, self.REG_PRESENT_TEMPERATURE, 1)
        if resp and len(resp['data']) >= 2:
            return resp['data'][1]
        return None


class Gimbal:
    """二自由度云台控制"""
    
    def __init__(self, servo):
        self.servo = servo
        
        # 左右舵机 (ID1): 220~802, 中511
        self.pan_id = 1
        self.pan_min = 220
        self.pan_max = 802
        self.pan_mid = 511
        
        # 上下舵机 (ID2): 220~511, 中511
        self.tilt_id = 2
        self.tilt_min = 220
        self.tilt_max = 511
        self.tilt_mid = 511
        
        # 默认运动参数
        self.default_time = None  # 默认不设置时间
        self.default_speed = None  # 默认不设置速度
    
    def set_motion_params(self, time_ms=None, speed=None):
        """设置默认的运动参数"""
        self.default_time = time_ms
        self.default_speed = speed
    
    def enable_all(self):
        """使能所有舵机"""
        self.servo.enable_torque(self.pan_id, True)
        self.servo.enable_torque(self.tilt_id, True)
    
    def disable_all(self):
        """禁用所有舵机"""
        self.servo.enable_torque(self.pan_id, False)
        self.servo.enable_torque(self.tilt_id, False)
    
    def pan_to(self, position, time_ms=None, speed=None):
        """左右转到指定位置"""
        pos = max(self.pan_min, min(self.pan_max, position))
        t = time_ms if time_ms is not None else self.default_time
        s = speed if speed is not None else self.default_speed
        self.servo.set_position(self.pan_id, pos, t, s)
    
    def tilt_to(self, position, time_ms=None, speed=None):
        """上下转到指定位置"""
        pos = max(self.tilt_min, min(self.tilt_max, position))
        t = time_ms if time_ms is not None else self.default_time
        s = speed if speed is not None else self.default_speed
        self.servo.set_position(self.tilt_id, pos, t, s)
    
    def goto(self, pan_pos, tilt_pos, time_ms=None, speed=None):
        """同时控制左右和上下"""
        t = time_ms if time_ms is not None else self.default_time
        s = speed if speed is not None else self.default_speed
        self.pan_to(pan_pos, t, s)
        self.tilt_to(tilt_pos, t, s)
    
    def center(self, time_ms=None, speed=None):
        """回到中间位置"""
        self.goto(self.pan_mid, self.tilt_mid, time_ms, speed)
    
    def get_pan_pos(self):
        """获取当前左右位置"""
        return self.servo.get_position(self.pan_id)
    
    def get_tilt_pos(self):
        """获取当前上下位置"""
        return self.servo.get_position(self.tilt_id)

