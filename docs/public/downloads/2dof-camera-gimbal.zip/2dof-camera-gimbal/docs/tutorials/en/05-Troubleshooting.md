
# Troubleshooting

This section summarizes common problems and solutions to help users quickly diagnose and resolve various issues encountered during use.

---

## Hardware Issues

### Servo Not Responding
**Possible Causes:**
1. Servo power not connected
2. Poor connection between servo and driver board
3. Serial port connection failed
4. Servo not enabled

**Solutions:**
1. Check that servo power is correctly connected and powered
2. Check that servo and driver board wires are secure
3. Run `examples/diagnostic.py` to view diagnostic information
4. Ensure you pressed `C` to connect gimbal and servos are enabled

### Servo Movement Reversed
**Possible Causes:**
- Servo mounting direction or program control parameters need adjustment

**Solutions:**
Modify the `calculate_move` method in `src/trackers/tracking_controller.py`, invert the respective parameters:

```python
# If left/right reversed
delta_pan = -int(self.kp_pan * err_x)

# If up/down reversed
delta_tilt = -int(self.kp_tilt * err_y)
```

### Servo Vibration
**Possible Causes:**
- Tracking parameters too sensitive
- Dead zone range too small
- Servo overload or insufficient power

**Solutions:**
1. Increase `dead_zone` parameter
2. Increase `min_move_interval`
3. Decrease `kp_pan` and `kp_tilt`
4. Check power voltage is normal

### Serial Port Connection Failed
**Possible Causes:**
- Driver not installed
- Port number incorrect
- Port in use by other program
- Cable issue

**Solutions:**
1. On Windows, check Device Manager to confirm driver is installed
2. Run `examples/list_ports.py` to find correct port
3. Close other programs that might be using the serial port
4. Try changing USB port or cable

---

## Software Issues

### Camera Won't Open
**Possible Causes:**
- Camera index incorrect
- Camera in use by other program
- Camera hardware connection issue
- Camera driver issue

**Solutions:**
1. Run `examples/list_cameras.py` to view available indices
2. Close other programs that might be using the camera
3. Check camera connection is normal
4. Try changing USB port

### OpenCV Errors
**Possible Causes:**
- OpenCV version issue
- Dependencies installed incompletely
- Camera hardware issue

**Solutions:**
1. Try reinstalling dependencies:
   ```bash
   pip install --upgrade opencv-python numpy
   ```
2. Check Python version meets requirements (>=3.8)
3. Examine error stack to locate problematic code

### Dependency Installation Failed
**Possible Causes:**
- pip version too old
- Network connection issue
- Permission issue

**Solutions:**
1. Upgrade pip first:
   ```bash
   pip install --upgrade pip
   ```
2. Use Chinese mirror for faster installation:
   ```bash
   pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
   ```
3. Check network connection is normal

### Program Startup Slow
**Possible Causes:**
- DSHOW not used on Windows
- Camera hardware initialization takes time

**Solutions:**
1. Confirm code uses `cv2.CAP_DSHOW` as camera backend
2. Check for other programs using the camera
3. Wait a few seconds, camera initialization usually takes time

---

## Tracking Issues

### Target Detection Inaccurate
**When Using Color Tracking:**
- Check target color and background have clear contrast
- Adjust color parameters (in `src/detectors/color_detector.py`)
- Ensure lighting is adequate and uniform

**When Using Face Tracking:**
- Lighting should be adequate, avoid backlighting
- Face should face camera directly
- Maintain appropriate distance

### Gimbal Doesn't Move While Tracking
**Possible Causes:**
1. Gimbal not connected
2. Target not locked
3. Target within dead zone
4. Program error

**Solutions:**
1. Confirm you pressed `C` to connect gimbal
2. Confirm you pressed `T` to lock target
3. Check console output for error messages
4. Verify target is not within `dead_zone` range

### Tracking Direction Reversed
**Solutions:**
Refer to "Servo Movement Reversed" solutions above.

### Tracking Vibration
**Solutions:**
Refer to "Servo Vibration" solutions above.

### Target Locking Failed
**Possible Causes:**
1. Target not in center of frame at lock time
2. Target too small or color not distinct
3. Target not detected

**Solutions:**
1. Ensure target is in center of frame when locking
2. Target size appropriate, can be detected correctly
3. Examine console output to confirm target detected
4. Readjust target position and try locking again

---

## Using Diagnostic Tools

### Using Diagnostic Program
The system provides comprehensive diagnostic tools that can test the entire system hardware:

```bash
python examples/diagnostic.py --camera 0 --port COM3
```

Diagnostic program will test in sequence:
1. Camera working normally
2. Serial port connects properly
3. Servos respond properly

Diagnostic completion will display test results to help locate issues.

### Viewing Debug Output
While program runs, console outputs relevant debug information including:
- Detected target information
- Target coordinates
- Error values
- Gimbal movement commands
- Any error messages

Careful observation of these outputs helps quickly locate issues.

---

## Recovery Methods

### Return Gimbal to Safe Position
- Press `R` to return to center
- Or call `gimbal.return_to_center()`

### Reset All Settings
- Press `S` to stop tracking
- Press `R` to return to center
- Lock target again

### Recalibrate
If tracking performance is significantly poor, you can:
1. Adjust tracking parameters
2. Lock target again
3. Restart program if needed
4. Check hardware connections

---

## Getting Help

If the above methods cannot resolve the issue, please record the following information:
- Operating system info
- Python version
- Detailed error information
- Steps to reproduce issue
- Results of running diagnostic
