
# Hardware and Environment Setup

This section provides detailed information about hardware assembly, connections, and environment configuration.

---

## Hardware List

Before using the product, please verify you have all the following components:

| Component Name | Model/Specification | Quantity |
|---------|----------|------|
| Servo | SCS009 | 2 |
| Gimbal Mount | 2-DOF gimbal structure | 1 |
| Servo Driver Board | CH343 chip driver | 1 |
| USB Camera | Minimum 640x480 resolution | 1 |
| Servo Power Supply | 4V-7.4V range, 6V recommended | 1 |
| Serial Data Cable | Connect driver to computer | 1 |

---

## Servo Parameters

| Parameter | Servo 1 (Left/Right) | Servo 2 (Up/Down) |
|------|-------------------|-------------------|
| Position Range | 220-802 | 220-511 |
| Center Position | 511 | 511 |
| Min Position | 220 (leftmost) | 220 (upmost) |
| Max Position | 802 (rightmost) | 511 (neutral) |

---

## Hardware Connection

### Step 1: Install Servos and Gimbal Mount
1. Mount Servo 1 (left/right rotation) to the bottom gimbal mount, tighten screws securely
2. Mount Servo 2 (up/down tilt) to the upper gimbal mount, tighten screws securely
3. Install the camera mount structure as specified

### Step 2: Servo to Driver Connection
1. Connect both servo data cables to the driver board servo ports
2. Note the servo wire order, typically red (power), black (ground), white/yellow (signal)
3. Ensure servos connect to the correct IDs: Servo ID 1 for left/right, Servo ID 2 for up/down

### Step 3: Power and Serial Connection
1. Connect servo power supply to the driver board power port
2. Connect driver board to computer using the serial data cable
3. Connect camera to computer

---

## System and Environment Requirements

### Supported Operating Systems
- Windows 10/11
- Linux distributions (Ubuntu 20.04 or newer recommended)

### Python Version
Python 3.8 or newer

---

## Driver and Dependency Installation

### Install Serial Driver

#### Windows
1. Visit CH343 chip manufacturer website, download Windows driver installer
2. Run installer and follow setup prompts
3. Connect driver board to computer, device manager should show serial port

#### Linux
Most Linux distributions come with CH343 serial driver built-in, no extra installation needed. If encountering issues:
1. Check if kernel has driver loaded with `lsmod | grep ch343`
2. Try reconnecting device or reboot if not loaded

### Install Python Dependencies

Run this from the project root directory:

```bash
pip install -r requirements.txt
```

Project dependencies include:
- opencv-python: Image acquisition and processing
- numpy: Numerical computing
- pyserial: Serial communication

---

## Verify Hardware Connection

Before launching the full program, we can use tools to verify hardware connections.

### Find Available Cameras
Run the following command to list available cameras:

```bash
python examples/list_cameras.py
```

The program will detect and list all available cameras. Note the index of the camera you want to use.

### Find Available Serial Ports
Run the following command to list available serial ports:

```bash
python examples/list_ports.py
```

Note the serial port device name.

### Hardware Diagnostics
To perform comprehensive hardware testing, run the diagnostic tool:

```bash
python examples/diagnostic.py --camera 0 --port COM3
```

The diagnostic program will test camera, serial port, and gimbal in sequence.

---

## Safety Notes

While using the system, please note these safety considerations:
1. Servo power must be within specified range (4V-7.4V) to prevent damage
2. Avoid leaving servos at their limit positions for extended periods for longevity
3. Recommend returning gimbal to center before powering off to reduce startup load
