
# Basic Usage

This section provides detailed information about basic gimbal control methods and workflows, to help users get comfortable with basic operations.

---

## Control Mode Overview

The gimbal system supports two main control modes:
1. Keyboard control: Manual gimbal control via keyboard keys
2. Automatic tracking: System automatically identifies and tracks targets

---

## Keyboard Control

### Keyboard Shortcuts

These are the keyboard shortcuts available in the main program:

| Key | Function Description |
|-----|----------|
| Arrow ← | Pan gimbal left |
| Arrow → | Pan gimbal right |
| Arrow ↑ | Tilt gimbal up |
| Arrow ↓ | Tilt gimbal down |
| C | Connect or disconnect gimbal |
| R | Return gimbal to center (initial position) |
| 1 | Switch to face tracking mode |
| 2 | Switch to color tracking mode |
| T | Lock/start tracking target |
| S | Stop tracking |
| X | Color mode: Track red objects |
| Y | Color mode: Track green objects |
| Z | Color mode: Track blue objects |
| Q | Quit program |

### Standalone Keyboard Control Example

You can also practice using the standalone keyboard control program:

```bash
python examples/keyboard_control.py --port COM3
```

This program only provides basic gimbal control, good for beginners to get started.

---

## Basic Operation Flow

### Startup and Connection

1. Launch the main program with the following command:
   ```bash
   python examples/auto_tracking_demo.py --camera 0 --port COM3
   ```
2. After program startup, press `C` to connect gimbal
3. Observe if servos respond normally, see Troubleshooting section if issues occur

### Manual Control Practice

1. Press arrow keys, observe if gimbal motion is as expected
2. Practice moving gimbal to various positions
3. Press `R` to return to center
4. Familiarize with gimbal minimum and maximum position limits

Recommended practice exercises:
- Exercise 1: Move gimbal to leftmost, rightmost, upmost, downmost positions to get comfortable with range
- Exercise 2: Return to center from arbitrary positions, observe if return is smooth
- Exercise 3: Try fine adjustments, familiarize with servo movement precision

---

## Basic Example Programs

The project provides several progressive examples for learning:

### Camera Only

```bash
python examples/01_camera_only.py --camera 0
```
This program only opens the camera, displays real-time feed, no gimbal control. Good for verifying camera functionality.

### Gimbal Only

```bash
python examples/02_gimbal_only.py --port COM3
```
This program only provides gimbal control, no camera. Good for verifying servo and driver connection.

### Camera and Gimbal Together

```bash
python examples/03_simple_gimbal_camera.py --camera 0 --port COM3
```
This program combines camera display and gimbal control, allows observing feed and gimbal coordination.

---

## Usage Notes

During operation, please note the following:
1. After connecting gimbal, confirm servos are enabled
2. Avoid leaving gimbal at limit positions for extended periods during manual control
3. Avoid forcefully hitting gimbal mount during operation
4. Immediately power off and inspect if abnormal servo vibration or noise occurs
5. Recommend disconnecting power when not using for extended periods
