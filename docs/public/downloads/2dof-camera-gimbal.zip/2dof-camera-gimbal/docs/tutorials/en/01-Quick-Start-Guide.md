
# Quick Start Guide

This guide provides a quick way to get up and running with the 2-DOF camera gimbal system.

---

## Step 0: Find Available Devices

Before starting, we need to locate the correct camera and serial port.

### Find Available Cameras
```bash
python examples/list_cameras.py
```

The program will list all available cameras and their indices. Note the index of the camera you want to use (usually 0).

### Find Available Serial Ports
```bash
python examples/list_ports.py
```

The program will list all available serial ports. Note the serial port device name (COM3 on Windows, /dev/ttyUSB0 on Linux).

---

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

---

## Step 2: Run Step-by-Step Examples (Optional but Recommended)

To better understand the system, we recommend running these programs in order:

1. **01_camera_only.py** - Display camera feed only, no gimbal control
   ```bash
   python examples/01_camera_only.py --camera 0
   ```
   Verify your camera is working properly.

2. **02_gimbal_only.py** - Control gimbal only, no camera
   ```bash
   python examples/02_gimbal_only.py --port COM3
   ```
   Verify your gimbal and driver are working properly.

3. **03_simple_gimbal_camera.py** - Camera and gimbal together
   ```bash
   python examples/03_simple_gimbal_camera.py --camera 0 --port COM3
   ```
   Manual control of gimbal while viewing camera feed.

4. **04_color_track_simple.py** - Simple color tracking without locking
   ```bash
   python examples/04_color_track_simple.py --camera 0 --port COM3 --color red
   ```
   Basic automatic tracking demo.

---

## Step 3: Run Full Program

When you're comfortable with the basics, run the full automatic tracking program:

```bash
python examples/auto_tracking_demo.py --camera 0 --port COM3 --color red
```

---

## Keyboard Shortcuts

| Key | Function |
|-----|---------|
| `1` | Switch to face tracking mode |
| `2` | Switch to color tracking mode |
| `C` | Connect gimbal |
| `R` | Return gimbal to center |
| `T` | Lock/start tracking target |
| `S` | Stop tracking |
| `X` | Color mode: Red |
| `Y` | Color mode: Green |
| `Z` | Color mode: Blue |
| `Q` | Quit program |

---

## Quick Tracking Usage

### Color Tracking
1. Press `C` to connect gimbal
2. Press `2` to enter color tracking mode
3. Place target color object in center of frame
4. Press `T` to lock target
5. Move target, observe gimbal following

### Face Tracking
1. Press `C` to connect gimbal
2. Press `1` to enter face tracking mode
3. Position face in center of frame
4. Press `T` to lock target
5. Move face, observe gimbal following

---

## Common Quick Questions

Q: Program says serial port not found?
A: Run `list_ports.py` to find the correct port, then use the `--port` parameter.

Q: Camera won't open?
A: Run `list_cameras.py` to find correct index, use `--camera` parameter.

Q: Gimbal doesn't move?
A: Confirm you pressed `C` to connect, and gimbal power is connected.

Q: Tracking direction reversed?
A: See Troubleshooting section.
