
# Advanced Features and Tracking

This section provides detailed information about automatic tracking functionality, including color tracking, face tracking, QR code tracking, as well as the target locking mechanism and parameter tuning.

---

## Automatic Tracking Mode Overview

The system supports three automatic tracking modes:
1. Color tracking: Track objects of specified colors
2. Face tracking: Track human faces
3. QR code tracking: Track QR codes

---

## Color Tracking

### Color Selection
The system supports tracking these colors:
- Red
- Green
- Blue

You can switch colors via keyboard keys in the program:
- `X`: Select red
- `Y`: Select green
- `Z`: Select blue

### Color Tracking Usage Flow
1. Press `C` to connect gimbal
2. Press `2` to enter color tracking mode
3. Place target color object in center of frame
4. Press `T` to lock target
5. Move target, observe gimbal following

### Simple Color Tracking Example
You can also use the simple color tracking example program:

```bash
python examples/04_color_track_simple.py --camera 0 --port COM3 --color red
```

This program provides the most basic color tracking functionality, good for learning.

---

## Face Tracking

### Face Tracking Principle
The system uses OpenCV's Haar cascade classifier for face detection. When detecting a face, the system automatically calculates the target position and controls the gimbal to follow.

### Face Tracking Usage Flow
1. Press `C` to connect gimbal
2. Press `1` to enter face tracking mode
3. Position face in center of frame
4. Press `T` to lock target
5. Move face, gimbal will automatically follow

### Tips for Improving Face Detection Success Rate
- Keep lighting adequate, avoid backlighting
- Face should face the camera directly
- Maintain appropriate distance (1-3 meters recommended)
- Avoid multiple face scenarios, or use locking mechanism to fix tracking target

---

## QR Code Tracking

QR code tracking mode uses OpenCV's QRCodeDetector for QR code identification and localization. Usage is similar to the other two tracking modes:

1. Connect gimbal, enter QR code tracking mode
2. Place QR code in center of frame, press `T` to lock
3. Move QR code, observe gimbal following effect

---

## Target Locking Mechanism

### Purpose of Locking
The target locking mechanism is a critical feature of the system, its functions include:
- Record the target center position and size at locking
- When multiple targets appear, prioritize the target closest to the lock point
- Prevent frequent target switching, maintain tracking stability

### Locking Flow
1. Place target object in center of frame
2. Press `T` to lock
3. After successful lock, system will prioritize tracking the target most similar to when locked
4. Press `S` to cancel locking and stop tracking

### Selection Logic While Locked
During post-lock target selection, two factors are considered:
- Distance: Distance of target center from the lock point (70% weight)
- Size: Similarity of target size to when locked (30% weight)
- System will select the target with highest combined score for tracking

---

## Tracking Control Parameter Tuning

In `src/trackers/tracking_controller.py`, these are the tunable parameters:

| Parameter Name | Default Value | Description |
|-------|-------|------|
| kp_pan | 0.08 | Pan tracking proportional gain |
| kp_tilt | 0.12 | Tilt tracking proportional gain |
| dead_zone | 30 | Dead zone range (pixels), no gimbal movement within range |
| min_move_interval | 0.15 | Minimum movement interval (seconds), limits gimbal movement frequency |

### Parameter Adjustment Methods
- **Tracking too slow**: Increase `kp_pan` and `kp_tilt`
- **Tracking too sensitive causing vibration**: Decrease `kp_pan` and `kp_tilt`, or increase `min_move_interval`, or increase `dead_zone`
- **Frequent small adjustments causing vibration**: Increase `dead_zone`
- **Direction reversed**: Change sign of `delta_pan` or `delta_tilt` in `calculate_move` method

---

## Complete Example of Tracking Usage

Here is a complete usage flow example:

1. Start program:
   ```bash
   python examples/auto_tracking_demo.py --camera 0 --port COM3 --color red
   ```
2. Press `C` to connect gimbal
3. Press `2` to select color tracking mode
4. Place red object in center of frame
5. Press `T` to lock target
6. Move object, observe gimbal following effect
7. If changing to green, press `Y` then lock again with `T`
8. Press `S` to stop tracking, press `R` to return to center
9. Press `Q` to quit

---

## Advanced Development Tips

For custom functionality or secondary development, you can refer to:
- `src/sc_servo.py`: Servo communication low level
- `src/gimbal.py`: Gimbal control
- `src/trackers/tracking_controller.py`: Tracking controller
- `src/detectors/`: Various target detectors
