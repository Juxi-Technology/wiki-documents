
import cv2
import sys


def list_available_cameras(max_check=10):
    print("Searching for available cameras...")
    print("=" * 60)
    
    available = []
    
    for i in range(max_check):
        print(f"Checking camera index {i}...", end=" ")
        
        try:
            cap = cv2.VideoCapture(i, cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY)
            if cap.isOpened():
                w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                fps = cap.get(cv2.CAP_PROP_FPS)
                available.append({
                    "index": i,
                    "width": w,
                    "height": h,
                    "fps": fps
                })
                print(f"✓ OK! Resolution {w}x{h} @ {fps} fps")
                cap.release()
            else:
                print("✗ Not available")
        except Exception as e:
            print(f"✗ ERROR: {str(e)}")
    
    print("=" * 60)
    if available:
        print(f"\nFound {len(available)} available cameras!")
        for cam in available:
            print(f"  Index {cam['index']}: {cam['width']}x{cam['height']} @ {cam['fps']} fps")
        print("\nUsage example:")
        print(f"  python examples/auto_tracking_demo.py --camera {available[0]['index']}")
    else:
        print("\nNo available cameras found, please check connections!")
    return available


if __name__ == "__main__":
    list_available_cameras()
