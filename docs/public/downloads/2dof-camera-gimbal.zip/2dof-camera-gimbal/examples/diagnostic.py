
import sys
import os
import argparse
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from sc_servo import SCServo, Gimbal
import cv2
import time


def test_camera(camera_index=0):
    """Test camera"""
    print("\n" + "=" * 60)
    print("Test 1: Camera")
    print("=" * 60)
    try:
        print(f"\nTrying to open camera index {camera_index}...")
        
        if sys.platform == "win32":
            cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
        else:
            cap = cv2.VideoCapture(camera_index)
        
        if cap.isOpened():
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            
            # Read a few frames to verify
            print(f"✓ Camera opened: {width}x{height}")
            print("Reading a few frames to verify...")
            for i in range(3):
                ret, frame = cap.read()
                if ret:
                    print(f"  Frame {i+1}: ✓ OK")
                else:
                    print(f"  Frame {i+1}: ✗ FAILED")
            
            cap.release()
            print("✓ Camera test passed")
            return True
        else:
            print("✗ Cannot open camera")
            return False
            
    except Exception as e:
        print(f"✗ Camera test exception: {e}")
        return False


def test_serial(port="COM3"):
    """Test serial connection"""
    print("\n" + "=" * 60)
    print("Test 2: Serial Connection")
    print("=" * 60)
    try:
        print(f"\nTrying to connect to serial port {port}...")
        servo = SCServo(port)
        if servo.connect():
            print("✓ Serial connection successful")
            servo.disconnect()
            return True
        else:
            print("✗ Serial connection failed")
            return False
    except Exception as e:
        print(f"✗ Serial connection exception: {e}")
        return False


def test_gimbal(port="COM3"):
    """Test gimbal control"""
    print("\n" + "=" * 60)
    print("Test 3: Gimbal Control")
    print("=" * 60)
    try:
        print(f"\nConnecting servo port {port}...")
        servo = SCServo(port)
        
        if not servo.connect():
            print("✗ Servo connection failed")
            return False
        
        print("✓ Servo connection successful")
        
        gimbal = Gimbal(servo)
        
        # Enable servo
        print("\nEnabling servo...")
        gimbal.enable_all()
        time.sleep(0.2)
        
        # Test return to center
        print("\nReturning gimbal to center...")
        gimbal.center()
        time.sleep(0.5)
        
        # Read current position
        pan_pos = gimbal.get_pan_pos() or 511
        tilt_pos = gimbal.get_tilt_pos() or 511
        print(f"Current position: Pan={pan_pos}, Tilt={tilt_pos}")
        
        # Test movement
        print("\nTesting gimbal movement (watch servo range!)")
        print("Press Enter to continue test, or press Q to skip...")
        try:
            choice = input()
            if choice.upper() == "Q":
                print("Skipping movement test")
            else:
                # Test left/right/up/down
                test_positions = [
                    (700, pan_pos),
                    (511, pan_pos),
                    (300, pan_pos),
                    (511, pan_pos),
                    (pan_pos, 400),
                    (pan_pos, 511),
                    (pan_pos, 511)
                ]
                
                for tilt, pan in test_positions:
                    print(f"Moving to Pan={pan}, Tilt={tilt}")
                    gimbal.pan_to(pan)
                    gimbal.tilt_to(tilt)
                    time.sleep(0.5)
                
                # Return to center
                print("\nReturning to center...")
                gimbal.center()
                time.sleep(0.5)
                
                # Read position again
                pan_pos_final = gimbal.get_pan_pos()
                tilt_pos_final = gimbal.get_tilt_pos()
                print(f"Final position: Pan={pan_pos_final}, Tilt={tilt_pos_final}")
                
                print("✓ Gimbal control test passed")
        except KeyboardInterrupt:
            print("\nTest interrupted")
        
        # Disable servo and disconnect
        print("\nDisabling servo...")
        gimbal.disable_all()
        time.sleep(0.1)
        
        servo.disconnect()
        print("✓ Disconnected")
        
        return True
    except Exception as e:
        print(f"✗ Gimbal control exception: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    print("=" * 60)
    print("2-DOF Camera Gimbal Diagnostic Tool")
    print("=" * 60)
    
    parser = argparse.ArgumentParser(description="Gimbal diagnostic tool")
    parser.add_argument("--camera", "-c", type=int, default=0, help="Camera index (default: 0)")
    parser.add_argument("--port", "-p", type=str, default="COM3", help="Serial port (default: COM3)")
    args = parser.parse_args()
    
    print(f"\nConfiguration:")
    print(f"  Camera index: {args.camera}")
    print(f"  Serial port: {args.port}")
    
    results = []
    
    # Test camera
    results.append(("Camera", test_camera(args.camera)))
    
    # Test serial
    results.append(("Serial Port", test_serial(args.port)))
    
    # Test gimbal control
    results.append(("Gimbal Control", test_gimbal(args.port)))
    
    # Print summary
    print("\n" + "=" * 60)
    print("Diagnostic Summary")
    print("=" * 60)
    
    all_passed = True
    for name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{name}: {status}")
        if not passed:
            all_passed = False
    
    print("=" * 60)
    if all_passed:
        print("All tests PASSED!")
    else:
        print("Some tests FAILED, please check hardware and connections!")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nProgram interrupted")
    except Exception as e:
        print(f"\nProgram exception: {e}")
        import traceback
        traceback.print_exc()
