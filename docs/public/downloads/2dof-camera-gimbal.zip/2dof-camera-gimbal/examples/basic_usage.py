
import sys
import os
import argparse
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from sc_servo import SCServo, Gimbal
import time


def main():
    parser = argparse.ArgumentParser(description="Basic gimbal usage demo")
    parser.add_argument("--port", "-p", type=str, default="COM3", help="Serial port")
    args = parser.parse_args()
    
    print("=" * 50)
    print("2-DOF Gimbal Control Demo")
    print("=" * 50)
    
    print("\nInitializing servo controller...")
    servo = SCServo(args.port)
    
    if servo.connect():
        print("✓ Serial port connected successfully")
        
        gimbal = Gimbal(servo)
        
        print("\nEnabling servo torque...")
        gimbal.enable_all()
        time.sleep(0.2)
        
        print("\nReading initial position...")
        pos1 = gimbal.get_pan_pos() or 511
        pos2 = gimbal.get_tilt_pos() or 511
        print(f"  Servo 1 (Pan) position: {pos1}")
        print(f"  Servo 2 (Tilt) position: {pos2}")
        
        print("\nReturning to center...")
        gimbal.center()
        time.sleep(1)
        
        print("\nPan/Left-right demonstration...")
        print("  Left...")
        gimbal.pan_to(350)
        time.sleep(1)
        print("  Right...")
        gimbal.pan_to(670)
        time.sleep(1)
        print("  Center...")
        gimbal.center()
        time.sleep(0.5)
        
        print("\nTilt/Up-down demonstration...")
        print("  Up...")
        gimbal.tilt_to(350)
        time.sleep(1)
        print("  Center...")
        gimbal.tilt_to(511)
        time.sleep(1)
        
        print("\nCombined motion demonstration...")
        gimbal.pan_to(380)
        gimbal.tilt_to(400)
        time.sleep(1)
        gimbal.pan_to(640)
        gimbal.tilt_to(450)
        time.sleep(1)
        gimbal.center()
        
        print("\nReading current status...")
        pan_pos = gimbal.get_pan_pos()
        tilt_pos = gimbal.get_tilt_pos()
        print(f"  Current pan position: {pan_pos}")
        print(f"  Current tilt position: {tilt_pos}")
        
        print("\nDone! Disconnecting...")
        gimbal.disable_all()
        servo.disconnect()
        print("Disconnected")
    else:
        print("✗ Connection failed! Please check serial port")
        print(f"  Current serial port: {args.port}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
