
import sys
import os
import argparse
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from sc_servo import SCServo, Gimbal
import time

STEP_SIZE = 20


def get_key_windows():
    try:
        import msvcrt
        if not msvcrt.kbhit():
            return None
        ch = msvcrt.getch()
        if ch == b'\x00' or ch == b'\xe0':
            ch2 = msvcrt.getch()
            if ch2 == b'H':
                return 'up'
            elif ch2 == b'P':
                return 'down'
            elif ch2 == b'M':
                return 'right'
            elif ch2 == b'K':
                return 'left'
            else:
                return None
        else:
            return ch.decode('utf-8', errors='ignore')
    except ImportError:
        return None


def main():
    parser = argparse.ArgumentParser(description="Gimbal control only - Step 2 tutorial")
    parser.add_argument("--port", "-p", type=str, default="COM3", help="Serial port (Windows: COMx, Linux: /dev/ttyUSBx)")
    args = parser.parse_args()
    
    print("=" * 60)
    print("Step 2: Control Gimbal Only")
    print("=" * 60)
    print(f"\nConnecting to serial port {args.port}...")
    
    servo = SCServo(args.port)
    if not servo.connect():
        print(f"✗ Cannot connect to {args.port}")
        print("Hint: Run list_ports.py to find available serial ports")
        return
    
    print("✓ Connection successful!")
    
    gimbal = Gimbal(servo)
    gimbal.set_motion_params(time_ms=300)
    gimbal.enable_all()
    
    print("\nReturning to center...")
    gimbal.center()
    time.sleep(0.5)
    
    print("\nInstructions:")
    print("  Arrow Keys: Move gimbal")
    print("  H: Return to center")
    print("  Q: Quit program")
    
    pan_pos = 511
    tilt_pos = 511
    
    try:
        while True:
            key = get_key_windows() if os.name == "nt" else None
            
            if key is not None:
                if key.lower() == "q":
                    break
                elif key.lower() == "h":
                    gimbal.center()
                    pan_pos = 511
                    tilt_pos = 511
                elif key == "left":
                    pan_pos = max(220, pan_pos - STEP_SIZE)
                    gimbal.pan_to(pan_pos)
                elif key == "right":
                    pan_pos = min(802, pan_pos + STEP_SIZE)
                    gimbal.pan_to(pan_pos)
                elif key == "up":
                    tilt_pos = max(220, tilt_pos - STEP_SIZE)
                    gimbal.tilt_to(tilt_pos)
                elif key == "down":
                    tilt_pos = min(511, tilt_pos + STEP_SIZE)
                    gimbal.tilt_to(tilt_pos)
                
                print(f"Current position: Pan={pan_pos}, Tilt={tilt_pos}", end="\r")
            
            time.sleep(0.01)
            
    except KeyboardInterrupt:
        print("\n\nInterrupt received")
    finally:
        print("\nReturning to center and disconnecting...")
        gimbal.center()
        time.sleep(0.5)
        gimbal.disable_all()
        servo.disconnect()
        print("\nClosed!")


if __name__ == "__main__":
    main()
