
import sys
import os
import time
import argparse
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

import cv2


class AutoTrackingDemo:
    def __init__(self, camera_index=0, serial_port="COM3", default_color="red"):
        print("=" * 60)
        print("  2-DOF Camera Gimbal Auto Tracking System")
        print("=" * 60)
        print()
        
        print("[1/3] Opening camera...")
        self.cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW) if sys.platform == "win32" else cv2.VideoCapture(camera_index)
        if not self.cap.isOpened():
            print("✗ Cannot open camera!")
            sys.exit(1)
        
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
        
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print(f"✓ Camera ready: {self.width}x{self.height} @ 30fps")
        print()
        
        self.face_detector = None
        self.color_detector = None
        self.gimbal = None
        self.tracking_controller = None
        self.gimbal_connected = False
        self.serial_port = serial_port
        self.default_color = default_color
        
        self.current_mode = 0
        self.mode_names = ["View Mode", "Face Track", "Color Track"]
        self.tracking_active = False
        self.locked_target = None
        self.locked_target_center = None
        self.locked_target_size = None
        
        cv2.namedWindow("Auto Tracking")
        
        print("[2/3] Initializing system...")
        print("✓ Initialization complete")
        print()
        print("[3/3] System ready!")
        print()
        print("  Keyboard shortcuts:")
        print("    1/2 - Switch mode (Face/Color)")
        print("    C - Connect gimbal")
        print("    R - Return to center")
        print("    T - Lock/start tracking")
        print("    S - Stop tracking")
        print("    X/Y/Z - Color mode: Red/Green/Blue")
        print("    Q - Quit program")
        print()
        print("=" * 60)
        print()
    
    def get_face_detector(self):
        if self.face_detector is None:
            from detectors import FaceDetector
            print("  Loading face detector...")
            self.face_detector = FaceDetector()
        return self.face_detector
    
    def get_color_detector(self):
        if self.color_detector is None:
            from detectors import ColorDetector
            print("  Loading color detector...")
            self.color_detector = ColorDetector(self.default_color)
        return self.color_detector
    
    def connect_gimbal(self):
        if self.gimbal_connected:
            print("  ✓ Gimbal already connected")
            return
        try:
            print("  Connecting gimbal and loading servo modules...")
            from sc_servo import SCServo, Gimbal
            from trackers.tracking_controller import TrackingController
            
            servo = SCServo(self.serial_port)
            if servo.connect():
                self.gimbal = Gimbal(servo)
                self.gimbal.enable_all()
                self.gimbal.set_motion_params(time_ms=500)
                time.sleep(0.2)
                pan = self.gimbal.get_pan_pos() or 511
                tilt = self.gimbal.get_tilt_pos() or 511
                self.tracking_controller = TrackingController(self.gimbal)
                self.tracking_controller.set_image_size(self.width, self.height)
                self.tracking_controller.set_current_positions(pan, tilt)
                self.gimbal_connected = True
                print(f"  ✓ Gimbal connected: Pan={pan}, Tilt={tilt}")
            else:
                print("  ✗ Connection failed, check serial port!")
        except Exception as e:
            print(f"  ✗ Gimbal error: {str(e)}")
    
    def start_tracking(self):
        if not self.gimbal_connected:
            print("  ✗ Press C to connect gimbal first!")
            return
        if self.current_mode not in [1, 2]:
            print("  ✗ Press 1 (Face) or 2 (Color) to select mode first!")
            return
        
        print("  Locking onto first detected target...")
        ret, frame = self.cap.read()
        if ret:
            if self.current_mode == 1:
                det = self.get_face_detector()
                annotated, detections = det.detect(frame.copy())
                print(f"  Detected {len(detections)} faces")
                for i, d in enumerate(detections):
                    x,y,w,h = d['bbox']
                    print(f"    Face {i}: ({x}, {y}, {w}, {h})")
                if detections:
                    best = detections[0]
                    x,y,w,h = best['bbox']
                    cx = x + w//2
                    cy = y + h//2
                    self.locked_target = {'type': 'face', 'box': (x,y,w,h)}
                    self.locked_target_center = (cx, cy)
                    self.locked_target_size = w*h
                    self.tracking_active = True
                    print(f"  ✓ Locked face: ({cx}, {cy}), size={self.locked_target_size}")
            elif self.current_mode == 2:
                det = self.get_color_detector()
                annotated, result = det.detect(frame.copy())
                if result['center'] is not None:
                    cx, cy = result['center']
                    self.locked_target = {'type': 'color', 'size': result['size']}
                    self.locked_target_center = (cx, cy)
                    self.locked_target_size = result['size']
                    self.tracking_active = True
                    print(f"  ✓ Locked color target: ({cx}, {cy}), size={self.locked_target_size}")
            else:
                print("  ✗ No target detected! Move target to center and try again!")
    
    def stop_tracking(self):
        self.tracking_active = False
        self.locked_target = None
        self.locked_target_center = None
        self.locked_target_size = None
        if self.tracking_controller:
            self.tracking_controller.clear_history()
        print("  ✓ Tracking stopped, target unlocked")
    
    def return_to_center(self):
        if not self.gimbal_connected:
            print("  ✗ Connect gimbal first!")
            return
        self.tracking_active = False
        self.locked_target = None
        self.locked_target_center = None
        self.locked_target_size = None
        print("  Returning to center...")
        self.tracking_controller.return_to_center()
    
    def find_best_matching_target(self, candidates):
        if not candidates:
            return None
        if self.locked_target_center is None:
            return candidates[0]
        
        lx, ly = self.locked_target_center
        best_idx = 0
        best_score = float('inf')
        
        for i, cand in enumerate(candidates):
            cx, cy = cand['center']
            dist = (cx - lx)**2 + (cy - ly)**2
            size_diff = 0
            if self.locked_target_size and 'size' in cand:
                size_diff = abs(cand['size'] - self.locked_target_size) / max(self.locked_target_size, cand['size'], 1)
            
            score = dist * 0.7 + size_diff * 100000 * 0.3
            
            if score < best_score:
                best_score = score
                best_idx = i
        
        return candidates[best_idx]
    
    def run(self):
        while True:
            ret, frame = self.cap.read()
            if not ret:
                break
            
            annotated = frame.copy()
            target_center = None
            
            if self.current_mode == 1:
                det = self.get_face_detector()
                annotated, detections = det.detect(annotated)
                
                if self.tracking_active and detections:
                    candidates = []
                    for i, d in enumerate(detections):
                        x,y,w,h = d['bbox']
                        cx = x + w//2
                        cy = y + h//2
                        candidates.append({'center': (cx, cy), 'box': (x,y,w,h), 'size': w*h, 'idx': i})
                    
                    best = self.find_best_matching_target(candidates)
                    if best:
                        x,y,w,h = best['box']
                        cx, cy = best['center']
                        target_center = (cx, cy)
                        cv2.circle(annotated, (cx, cy), 12, (0,0,255), 2)
                        cv2.rectangle(annotated, (x,y), (x+w,y+h), (0,0,255), 3)
                        cv2.putText(annotated, "LOCKED FACE #" + str(best['idx']), (10,140),
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
            
            elif self.current_mode == 2:
                det = self.get_color_detector()
                annotated, result = det.detect(annotated)
                
                if self.tracking_active and result['contours']:
                    candidates = []
                    for i, cnt in enumerate(result['contours']):
                        cx, cy = cnt['center']
                        candidates.append({'center': (cx, cy), 'size': cnt['size'], 'box': cnt['box'], 'idx': i})
                    
                    best = self.find_best_matching_target(candidates)
                    if best:
                        cx, cy = best['center']
                        target_center = (cx, cy)
                        x, y, w, h = best['box']
                        cv2.circle(annotated, (cx, cy), 12, (0,0,255), 2)
                        cv2.rectangle(annotated, (x, y), (x+w, y+h), (0,0,255), 3)
                        cv2.putText(annotated, "LOCKED COLOR #" + str(best['idx']), (10,140),
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
            
            if self.tracking_active and target_center is not None and self.tracking_controller:
                tx, ty = target_center
                self.tracking_controller.update(tx, ty)
            
            self.draw_ui(annotated)
            cv2.imshow("Auto Tracking", annotated)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('1'):
                self.current_mode = 1
                self.tracking_active = False
                self.locked_target = None
                self.locked_target_center = None
                self.locked_target_size = None
                print("  Mode: Face Tracking")
            elif key == ord('2'):
                self.current_mode = 2
                self.tracking_active = False
                self.locked_target = None
                self.locked_target_center = None
                self.locked_target_size = None
                print("  Mode: Color Tracking")
            elif key == ord('c'):
                self.connect_gimbal()
            elif key == ord('r'):
                self.return_to_center()
            elif key == ord('t'):
                self.start_tracking()
            elif key == ord('s'):
                self.stop_tracking()
            elif key == ord('x'):
                if self.current_mode == 2:
                    det = self.get_color_detector()
                    det.set_color('red')
                    print("  Color: Red")
            elif key == ord('y'):
                if self.current_mode == 2:
                    det = self.get_color_detector()
                    det.set_color('green')
                    print("  Color: Green")
            elif key == ord('z'):
                if self.current_mode == 2:
                    det = self.get_color_detector()
                    det.set_color('blue')
                    print("  Color: Blue")
        
        self.cleanup()
    
    def draw_ui(self, frame):
        h, w = frame.shape[:2]
        
        mode_text = "Mode: " + self.mode_names[self.current_mode]
        tracking_text = "Track: ON [LOCKED]" if self.tracking_active else "Track: OFF"
        connect_text = "Gimbal: ON" if self.gimbal_connected else "Gimbal: OFF"
        
        cv2.rectangle(frame, (5,5), (280, 105), (0,0,0), -1)
        cv2.putText(frame, mode_text, (10, 28),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        cv2.putText(frame, tracking_text, (10, 53),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        cv2.putText(frame, connect_text, (10, 78),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,0), 1)
        
        instructions = "1-2:Mode | C:Connect | R:Center | T:Lock | S:Stop | Q:Quit"
        cv2.rectangle(frame, (5, h-30), (w-5, h-5), (0,0,0), -1)
        cv2.putText(frame, instructions, (10, h-10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.38, (0,255,0), 1)
        
        if self.gimbal_connected and self.tracking_controller:
            pos_text = "Pan=" + str(self.tracking_controller.current_pan) + " Tilt=" + str(self.tracking_controller.current_tilt)
            cv2.putText(frame, pos_text, (w-210, h-10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255,0,255), 1)
    
    def cleanup(self):
        if self.gimbal_connected and self.gimbal:
            try:
                self.gimbal.disable_all()
                self.gimbal.servo.disconnect()
            except:
                pass
        self.cap.release()
        cv2.destroyAllWindows()
        print()
        print("=" * 60)
        print("  System shutdown")
        print("=" * 60)


def main():
    parser = argparse.ArgumentParser(description="2-DOF Camera Gimbal Auto Tracking System")
    parser.add_argument("--camera", "-c", type=int, default=0, help="Camera index (default: 0)")
    parser.add_argument("--port", "-p", type=str, default="COM3", help="Serial port (default: COM3)")
    parser.add_argument("--color", "-C", type=str, default="red", help="Default color (red/green/blue/yellow)")
    args = parser.parse_args()
    
    demo = AutoTrackingDemo(
        camera_index=args.camera,
        serial_port=args.port,
        default_color=args.color
    )
    demo.run()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
