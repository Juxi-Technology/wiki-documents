
import sys
import os
import argparse
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from sc_servo import SCServo, Gimbal
import time

# Check if on Windows and import appropriate keyboard module
try:
    import msvcrt
except ImportError:
    print("WARNING: This program works best on Windows with msvcrt.")
    print("Falling back to simple input mode.")

# Movement step size (how much position changes per key press)
STEP_SIZE = 20


def get_key_windows():
    """
    Read a single key from keyboard on Windows.
    Supports arrow keys and other special keys.
    """
    if not msvcrt.kbhit():
        return None
    
    ch = msvcrt.getch()
    
    # Handle special keys (two-byte sequences)
    if ch == b'\x00' or ch == b'\xe0':
        ch2 = msvcrt.getch()
        if ch2 == b'H':
            return 'up'
        elif ch2 == b'P':
            return 'down'
        elif ch2 == b'M':
            return 'right'
        elif ch2 == b'K':
            return 'left'
        else:
            return None
    else:
        # Return regular character
        return ch.decode('utf-8', errors='ignore')


def redraw_interface(pan_pos, tilt_pos):
    """
    Redraw the interface without scrolling.
    """
    # Clear screen completely and redraw
    os.system('cls')
    
    print("=" * 70)
    print("Interactive Gimbal Control - Arrow Key Driver")
    print("=" * 70)
    print("\nControls:")
    print("  Arrow Keys:")
    print("    Left/Right: Pan (horizontal) movement")
    print("    Up/Down: Tilt (vertical) movement")
    print("  H: Home (return to center)")
    print("  Q: Quit program")
    print()
    print("Step size: {} (adjust in code)".format(STEP_SIZE))
    print("Safety limits:")
    print("  Pan: 220 - 802")
    print("  Tilt: 220 - 511")
    print()
    print("-" * 70)
    print("CURRENT POSITION")
    print("-" * 70)
    print("  Pan (left/right): {:4d}".format(pan_pos))
    print("  Tilt (up/down): {:4d}".format(tilt_pos))
    print("-" * 70)
    print()


def main():
    parser = argparse.ArgumentParser(description="Interactive Gimbal Control - Arrow Key Driver")
    parser.add_argument("--port", "-p", type=str, default="COM3", help="Serial port")
    args = parser.parse_args()
    
    # Initial setup
    print("=" * 70)
    print("Interactive Gimbal Control - Arrow Key Driver")
    print("=" * 70)
    print("\nControls:")
    print("  Arrow Keys:")
    print("    Left/Right: Pan (horizontal) movement")
    print("    Up/Down: Tilt (vertical) movement")
    print("  H: Home (return to center)")
    print("  Q: Quit program")
    print()
    print("Step size: {} (adjust in code)".format(STEP_SIZE))
    print("Safety limits:")
    print("  Pan: 220 - 802")
    print("  Tilt: 220 - 511")
    print()
    print("Press any key to start...")

    # Wait for key press to start
    input()

    # Initialize servo
    print("\nConnecting to servo...")
    servo = SCServo(args.port)
    if not servo.connect():
        print("ERROR: Failed to connect to servo!")
        return
    print("Connected successfully!")

    gimbal = Gimbal(servo)

    # Set slow movement for better control
    gimbal.set_motion_params(time_ms=300)

    # Start with torque disabled for safety
    print("\nDisabling torque first - adjust gimbal to safe position manually")
    gimbal.disable_all()
    input("Press Enter to continue...")

    print("\nEnabling torque now...")
    gimbal.enable_all()
    time.sleep(0.3)

    # Go to center to start
    print("Going to center position...")
    gimbal.center()
    time.sleep(1)

    # Initialize position
    pan_pos = 511
    tilt_pos = 511

    # Clear screen and show initial interface
    os.system('cls')
    redraw_interface(pan_pos, tilt_pos)

    try:
        while True:
            # Wait for key before doing anything - NO constant redrawing!
            key = get_key_windows()

            if key is not None:
                if key == 'q' or key == 'Q':
                    break

                elif key == 'h' or key == 'H':
                    gimbal.center()
                    time.sleep(0.3)
                    pan_pos = 511
                    tilt_pos = 511

                elif key == 'left':
                    pan_pos = max(220, pan_pos - STEP_SIZE)
                    gimbal.pan_to(pan_pos)

                elif key == 'right':
                    pan_pos = min(802, pan_pos + STEP_SIZE)
                    gimbal.pan_to(pan_pos)

                elif key == 'up':
                    tilt_pos = max(220, tilt_pos - STEP_SIZE)
                    gimbal.tilt_to(tilt_pos)

                elif key == 'down':
                    tilt_pos = min(511, tilt_pos + STEP_SIZE)
                    gimbal.tilt_to(tilt_pos)
                
                # Only redraw interface if we got a valid key and position changed
                redraw_interface(pan_pos, tilt_pos)

            else:
                # No key - just wait a bit to not use 100% CPU
                time.sleep(0.01)

    except KeyboardInterrupt:
        print("\nKeyboard interrupt received.")

    finally:
        os.system('cls')
        print("\nReturning to center position...")
        gimbal.center()
        time.sleep(1)
        print("Disabling torque...")
        gimbal.disable_all()
        time.sleep(0.3)
        print("Disconnecting...")
        servo.disconnect()
        print("\n" + "=" * 70)
        print("Program ended. Have a nice day!")
        print("=" * 70)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
