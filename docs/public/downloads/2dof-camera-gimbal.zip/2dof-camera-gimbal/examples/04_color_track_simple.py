
import sys
import os
import argparse
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from sc_servo import SCServo, Gimbal
from detectors import ColorDetector
import cv2
import time


def main():
    parser = argparse.ArgumentParser(description="Simple color tracking - Step 4 tutorial")
    parser.add_argument("--camera", "-c", type=int, default=0, help="Camera index (default: 0)")
    parser.add_argument("--port", "-p", type=str, default="COM3", help="Serial port (default: COM3)")
    parser.add_argument("--color", "-C", type=str, default="red", help="Target color (red/green/blue/yellow)")
    args = parser.parse_args()
    
    print("=" * 60)
    print("Step 4: Simple Color Tracking")
    print("=" * 60)
    
    print(f"\nOpening camera index {args.camera}...")
    if sys.platform == "win32":
        cap = cv2.VideoCapture(args.camera, cv2.CAP_DSHOW)
    else:
        cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        print(f"✗ Cannot open camera index {args.camera}")
        return
    print("✓ Camera opened!")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    print(f"\nConnecting to serial port {args.port}...")
    servo = SCServo(args.port)
    if not servo.connect():
        print(f"✗ Cannot connect to {args.port}")
        cap.release()
        return
    print("✓ Gimbal connected!")
    
    gimbal = Gimbal(servo)
    gimbal.set_motion_params(time_ms=300)
    gimbal.enable_all()
    gimbal.center()
    time.sleep(0.5)
    
    det = ColorDetector(args.color)
    
    kp_pan = 0.08
    kp_tilt = 0.12
    dead_zone = 40
    
    pan_pos = 511
    tilt_pos = 511
    
    print(f"\nTracking {args.color} color...")
    print("Instructions: Q - Quit program")
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            ann, result = det.detect(frame.copy())
            
            if result["center"] is not None:
                cx, cy = result["center"]
                err_x = cx - 320
                err_y = cy - 240
                
                if abs(err_x) > dead_zone or abs(err_y) > dead_zone:
                    delta_pan = int(kp_pan * err_x)
                    delta_tilt = int(kp_tilt * err_y)
                    pan_pos = max(220, min(802, pan_pos + delta_pan))
                    tilt_pos = max(220, min(511, tilt_pos + delta_tilt))
                    gimbal.pan_to(pan_pos)
                    gimbal.tilt_to(tilt_pos)
                
                cv2.putText(ann, f"Tracking - Pan={pan_pos}, Tilt={tilt_pos}", (10, 30),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                cv2.putText(ann, f"Err X={err_x}, Y={err_y}", (10, 60),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            else:
                cv2.putText(ann, "No target detected", (10, 30),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            cv2.imshow("Step 4: Simple Color Tracking", ann)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            
            time.sleep(0.01)
            
    except KeyboardInterrupt:
        print("\n\nInterrupt received")
    finally:
        print("\nReturning to center and disconnecting...")
        gimbal.center()
        time.sleep(0.5)
        gimbal.disable_all()
        servo.disconnect()
        cap.release()
        cv2.destroyAllWindows()
        print("\nClosed!")


if __name__ == "__main__":
    main()
