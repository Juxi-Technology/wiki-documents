
import cv2
import sys
import argparse


def main():
    parser = argparse.ArgumentParser(description="Camera only display - Step 1 tutorial")
    parser.add_argument("--camera", "-c", type=int, default=0, help="Camera index (default: 0)")
    args = parser.parse_args()
    
    print("=" * 60)
    print("Step 1: Open Camera Only")
    print("=" * 60)
    print(f"\nOpening camera index {args.camera}...")
    
    if sys.platform == "win32":
        cap = cv2.VideoCapture(args.camera, cv2.CAP_DSHOW)
    else:
        cap = cv2.VideoCapture(args.camera)
    
    if not cap.isOpened():
        print(f"✗ Cannot open camera index {args.camera}")
        print("Hint: Run list_cameras.py to find available cameras")
        return
    
    print("✓ Camera opened!")
    print("\nInstructions:")
    print("  Q - Quit program")
    
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to read from camera!")
            break
        
        cv2.putText(frame, "Camera Only - Press Q to quit", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        cv2.imshow("Camera Only", frame)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    print("\nClosed!")


if __name__ == "__main__":
    main()
