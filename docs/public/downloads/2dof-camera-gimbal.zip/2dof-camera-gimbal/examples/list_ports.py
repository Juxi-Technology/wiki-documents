
import sys


def list_available_ports():
    print("Searching for available serial ports...")
    print("=" * 60)
    
    available = []
    
    try:
        if sys.platform.startswith("win"):
            available = _list_windows_ports()
        else:
            available = _list_linux_ports()
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return []
    
    print("=" * 60)
    
    if available:
        print(f"\nFound {len(available)} available serial ports!")
        for port in available:
            print(f"  {port}")
        print("\nUsage example:")
        print(f"  python examples/auto_tracking_demo.py --port {available[0]}")
    else:
        print("\nNo available serial ports found, please check connections and drivers!")
        print("\nHint: If using FT servo, please ensure USB serial driver is installed!")
    
    return available


def _list_windows_ports():
    print("Windows system detected")
    available = []
    
    try:
        import serial.tools.list_ports as list_ports
        ports = list_ports.comports()
        
        for port in ports:
            available.append(port.device)
            print(f"  Found: {port.device} - {port.description}")
            
    except ImportError:
        print("pyserial missing, trying fallback method...")
        import winreg
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM")
            index = 0
            while True:
                try:
                    _, value, _ = winreg.EnumValue(key, index)
                    available.append(value)
                    print(f"  Found: {value}")
                    index += 1
                except WindowsError:
                    break
        except Exception as e:
            print(f"  Fallback method failed: {str(e)}")
    
    return available


def _list_linux_ports():
    print("Linux system detected")
    import glob
    
    available = []
    
    for pattern in ['/dev/ttyUSB*', '/dev/ttyACM*', '/dev/ttyS*']:
        ports = glob.glob(pattern)
        for port in ports:
            available.append(port)
            print(f"  Found: {port}")
    
    return available


if __name__ == "__main__":
    list_available_ports()
