# AmazingHand 灵巧手 — 使用说明

> **重要**：请将本交付包**解压到全英文路径**（如 `D:\Hand\delivery_package`）。
> ESP-IDF 固件编译不支持中文路径，放到含中文的文件夹（如"下载"或带中文用户名的路径）会编译失败。

欢迎使用 AmazingHand 灵巧手！本包包含两条独立的产品线：

| 目录 | 用途 |
|------|------|
| `01_gui_control/` | 电脑上位机，点按钮让灵巧手做手势 |
| `02_hand_tracking/` | 摄像头识别手势，灵巧手实时跟随 |
| `03_firmware_docs/` | 固件源码 + 完整文档 |
| `04_scs0009_official/` | 官方总线舵机版说明（如不使用可忽略） |

## 我该用哪个？

- **刚拿到手**：先看 `03_firmware_docs/` 里的 `用户手册.md`，确认固件已烧录、硬件接线正确。
- **想"点按钮做手势"**：打开 `01_gui_control/`，双击 `AmazingHand控制台.exe`，或用里面的 `使用教程.md`。
- **想"摄像头手势跟随"**：看 `02_hand_tracking/` 里的 `手势追踪教程.md`，按步骤部署并运行。

## 两条产品线关系

- `01 可视化` 和 `02 追踪` 是**两套独立的软件**，但共用同一套硬件（ESP32-S3 + 8 路 PWM 舵机）。
- 任一时刻用其中一种方式控制灵巧手即可，**不要同时开两个**。

## 目录速览

```
01_gui_control\
   AmazingHand控制台.exe     打包好的上位机（免装 Python）
   hand_gui.py               上位机源码（GUI）
   serial_test.py            命令行测试工具
   setup_tracking.bat        安装追踪依赖
   使用教程.md               怎么用，看这个

02_hand_tracking\
   手势追踪教程.md           怎么用，看这个
   Demo\                     追踪程序源码 + 一键部署脚本

03_firmware_docs\
   esp-idf\AmazingHand_Serial\   ESP-IDF 版固件
   amazinghand_pwm.bin       合并固件（客户可直接烧录）
   用户手册.md                    完整协议/命令/硬件说明
   全流程使用教程.md               从手势指令到手势追踪全流程

04_scs0009_official\
   使用说明.md                 官方总线舵机版说明
```

## 快速上手（最短路径）

1. 固件已烧录 + ESP32 通电 + USB 接好（看设备管理器确认 COM 口）。
2. 想点按钮：打开 `01_gui_control/`，双击 exe，选串口 → 连接 → 点手势。
3. 想追踪：看 `02_hand_tracking/` 的教程，跑 `4-运行代码.bat` 选 `3（PWM）` → 选手型。

## 常见问题

常见问题请见各目录内的教程"常见问题"一节，或 `03_firmware_docs/全流程使用教程.md` 第 6 章。
