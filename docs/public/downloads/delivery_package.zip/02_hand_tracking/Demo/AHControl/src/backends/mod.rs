//! 舵机后端抽象: 支持 SCS0009 总线舵机和 PWM 舵机无缝切换。
//!
//! 上层数据流(摄像头 → mediapipe → IK → 8关节角)完全一致, 只有底层舵机驱动不同。
//! 通过 `driver` 配置选择后端: "scs0009" (官方原版) 或 "pwm" (ESP32 PWM 直驱)。

pub mod pwm;
pub mod scs0009;

use eyre::Result;

/// 舵机后端统一接口。
///
/// 约定: `goals_rad` 传入**弧度**(= main.rs 里 `buffer[idx] + offset`, invert 取负后的值),
/// 与 SCS0009 官方路径保持一致; 各后端自行换算为自身原生单位。
pub trait ServoBackend {
    /// 舵机上电/断电。PWM 后端可 no-op。
    fn torque_enable(&mut self, ids: &[u8], on: bool) -> Result<()>;

    /// 写入多个舵机目标位置(弧度)。
    fn write_goal_positions(&mut self, ids: &[u8], goals_rad: &[f64]) -> Result<()>;

    /// 等待硬件就绪(默认 no-op, PWM 后端用于等待 ESP32 固件启动)。
    fn wait_for_esp32(&mut self) -> Result<()> {
        Ok(())
    }

    /// 后端名称, 用于日志。
    fn name(&self) -> &'static str {
        "unknown"
    }
}

/// 根据配置选择并创建舵机后端。
///
/// - `driver`: "scs0009" 或 "pwm"; None 或缺省按老逻辑走 scs0009。
/// - `port`: 串口设备 (如 COM27, /dev/ttyACM0)。
/// - `baud`: 波特率。
pub fn factory(
    driver: Option<&str>,
    port: &str,
    baud: u32,
) -> Result<Box<dyn ServoBackend>> {
    match driver.unwrap_or("scs0009") {
        "pwm" => Ok(Box::new(pwm::PwmBackend::new(port, baud)?)),
        "scs0009" => Ok(Box::new(scs0009::Scs0009Backend::new(port, baud)?)),
        other => eyre::bail!("unknown servo driver: {other} (available: scs0009 / pwm)"),
    }
}
