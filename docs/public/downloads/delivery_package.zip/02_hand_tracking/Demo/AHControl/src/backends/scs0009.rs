//! SCS0009 总线舵机后端 (官方原逻辑封装)。

use std::time::Duration;

use eyre::{eyre, Result};
use rustypot::servo;

use super::ServoBackend;

pub struct Scs0009Backend {
    controller: servo::feetech::scs0009::Scs0009Controller,
}

impl Scs0009Backend {
    pub fn new(port: &str, baud: u32) -> Result<Self> {
        let serial_port = serialport::new(port, baud)
            .timeout(Duration::from_millis(10))
            .open()
            .map_err(|e| eyre!("open serial port {port} failed: {e}"))?;

        let controller = servo::feetech::scs0009::Scs0009Controller::new()
            .with_protocol_v1()
            .with_serial_port(serial_port);

        Ok(Self { controller })
    }
}

impl ServoBackend for Scs0009Backend {
    fn torque_enable(&mut self, ids: &[u8], on: bool) -> Result<()> {
        let val: Vec<u8> = ids.iter().map(|_| if on { 1 } else { 0 }).collect();
        self.controller
            .sync_write_torque_enable(ids, &val)
            .map_err(|e| eyre!("servo torque control failed: {e}"))
    }

    fn write_goal_positions(&mut self, ids: &[u8], goals_rad: &[f64]) -> Result<()> {
        self.controller
            .sync_write_goal_position(ids, goals_rad)
            .map_err(|e| eyre!("write servo position failed: {e}"))
    }

    fn name(&self) -> &'static str {
        "scs0009"
    }
}
