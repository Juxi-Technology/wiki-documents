//! PWM 舵机后端 (ESP32-S3 直驱协议)。
//!
//! 帧格式: `0xAA 0xF0 0x08 [8字节角度] CHECKSUM`
//!   - 角度 0-180°, 每字节一个舵机
//!   - CHECKSUM = 0xF0 ^ 0x08 ^ 角度[0..7]
//! 关节角(弧度) → 角度: 关节 range ±90°(±π/2), deg = rad*(180/π) + 90
//! 配置的舵机 id(1..=8) 即通道号: chan = id-1, 未出现的通道填 neutral_deg。

use std::io::Read;
use std::time::Duration;

use eyre::{eyre, Result};

use super::ServoBackend;
const FRAME_HEADER: u8 = 0xAA;
const CMD_DIRECT_DRIVE: u8 = 0xF0;
const NUM_SERVOS: usize = 8;
/// 角度软限位: 避免舵机冲到 0°/180° 极限, 防止瞬间大电流拖垮 ESP32 供电
const MIN_ANGLE: u8 = 20;
const MAX_ANGLE: u8 = 160;

pub struct PwmBackend {
    port: Box<dyn serialport::SerialPort>,
    neutral_deg: u8,
    /// 发送节流: 两次发送的最小间隔 (ms)
    min_interval_ms: u64,
    last_send_ms: u128,
    /// EMA 平滑角度 (0-180), None 表示未初始化
    smooth_deg: Option<[f32; NUM_SERVOS]>,
    /// 发送帧数 / 收到 ESP32 ACK 帧数 (诊断用)
    send_count: u64,
    ack_count: u64,
}

impl PwmBackend {
    /// 打开 ESP32 PWM 直驱串口。`neutral_deg`: 机械中性角度(默认 90)。
    pub fn new(port: &str, baud: u32) -> Result<Self> {
        let mut port: Box<dyn serialport::SerialPort> = serialport::new(port, baud)
            .timeout(Duration::from_millis(10))
            .open()
            .map_err(|e| eyre!("open serial port {port} failed: {e}"))?;
        // 关键: 禁用 DTR/RTS, 防止打开串口时复位 ESP32 (导致固件反复重启)
        let _ = port.write_data_terminal_ready(false);
        let _ = port.write_request_to_send(false);
        Ok(Self {
            port,
            neutral_deg: 90,
            min_interval_ms: 30,  // ~33Hz 发送上限
            last_send_ms: 0,
            smooth_deg: None,
            send_count: 0,
            ack_count: 0,
        })
    }

    /// 等待 ESP32 固件启动。若打开串口触发了复位, 需要等待重启完成。
    /// 随后做一次启动自检: 发一帧 90° 中立直驱帧, 读回包, 确认 ESP32 活着。
    pub fn wait_for_esp32(&mut self) -> Result<()> {
        // 清空输入缓冲, 等待 3 秒让 ESP32 稳定
        let mut buf = [0u8; 256];
        let _ = self.port.read(&mut buf);
        std::thread::sleep(Duration::from_millis(3000));
        // 再次清空启动日志
        let _ = self.port.read(&mut buf);

        // 启动自检: 发一帧全 90° 中立, 读 2 秒等 BB F0 ACK
        let mut angles = [90u8; NUM_SERVOS];
        let mut cs = CMD_DIRECT_DRIVE ^ NUM_SERVOS as u8;
        for a in angles {
            cs ^= a;
        }
        let mut frame = [0u8; 12];
        frame[0] = FRAME_HEADER;
        frame[1] = CMD_DIRECT_DRIVE;
        frame[2] = NUM_SERVOS as u8;
        frame[3..11].copy_from_slice(&angles);
        frame[11] = cs;
        use std::io::Write;
        self.port.write_all(&frame).map_err(|e| eyre!("self-check: write frame failed {e}"))?;
        println!("[SELF-CHECK] sent 90 deg frame, waiting for ESP32 reply...");
        let deadline = std::time::Instant::now() + Duration::from_millis(2000);
        let mut got = Vec::new();
        while std::time::Instant::now() < deadline {
            match self.port.read(&mut buf) {
                Ok(n) if n > 0 => got.extend_from_slice(&buf[..n]),
                Ok(_) => {}
                Err(_) => break,
            }
        }
        if got.windows(4).any(|w| w == &[0xBB, CMD_DIRECT_DRIVE, 0x00, CMD_DIRECT_DRIVE ^ 0x00]) {
            println!("[SELF-CHECK] OK: ESP32 ACK received, serial link OK");
            let _ = std::fs::write("pwm_selfcheck.log", "SELF-CHECK OK: ESP32 ACK received, serial link OK\n");
        } else {
            println!(
                "[SELF-CHECK] !! no ESP32 reply (got {:02X?}) -- check COM port/baudrate/power",
                got
            );
            let _ = std::fs::write(
                "pwm_selfcheck.log",
                format!("SELF-CHECK FAIL: no reply, got {:02X?}\n", got),
            );
        }
        Ok(())
    }

    /// 关节角(弧度 ±π/2) → PWM 角度(0-180), 限制在 [MIN_ANGLE, MAX_ANGLE]。
    fn rad_to_deg(rad: f64, neutral_deg: u8) -> u8 {
        let deg = rad.to_degrees() + f64::from(neutral_deg);
        deg.clamp(f64::from(MIN_ANGLE), f64::from(MAX_ANGLE)).round() as u8
    }

    /// 组帧: 8 通道角度 → 12 字节直驱帧。
    fn build_frame(angles: &[u8; NUM_SERVOS]) -> [u8; 12] {
        let mut frame = [0u8; 12];
        frame[0] = FRAME_HEADER;
        frame[1] = CMD_DIRECT_DRIVE;
        frame[2] = NUM_SERVOS as u8;
        frame[3..11].copy_from_slice(angles);
        // CHECKSUM = F0 ^ 08 ^ ang[0..7]
        let mut cs = CMD_DIRECT_DRIVE ^ NUM_SERVOS as u8;
        for a in angles {
            cs ^= a;
        }
        frame[11] = cs;
        frame
    }

    /// 把 (id, 弧度) 列表组帧并写入串口。带节流 + EMA 平滑, 避免高频抖动。
    fn send_angles(&mut self, ids: &[u8], goals_rad: &[f64]) -> Result<()> {
        use std::io::Write;
        use std::time::{SystemTime, UNIX_EPOCH};

        // 1. 计算目标角度
        let mut target = [self.neutral_deg as f32; NUM_SERVOS];
        for (id, rad) in ids.iter().zip(goals_rad) {
            if *id == 0 || *id > NUM_SERVOS as u8 {
                eyre::bail!("servo id {id} out of range (1-{NUM_SERVOS})");
            }
            target[(*id - 1) as usize] = f32::from(Self::rad_to_deg(*rad, self.neutral_deg));
        }

        // 2. EMA 平滑 (alpha=0.5, 平滑但不迟钝)
        let smooth = match self.smooth_deg {
            Some(prev) => {
                let alpha = 0.5f32;
                let mut out = [0f32; NUM_SERVOS];
                for i in 0..NUM_SERVOS {
                    out[i] = prev[i] + alpha * (target[i] - prev[i]);
                }
                out
            }
            None => target,
        };
        self.smooth_deg = Some(smooth);

        // 3. 转 u8
        let angles = [0u8; NUM_SERVOS];
        let mut angles = angles;
        for i in 0..NUM_SERVOS {
            angles[i] = smooth[i].round() as u8;
        }

        // 4. 节流: 距上次发送 >= min_interval_ms 才发
        let now_ms = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0);
        if now_ms - self.last_send_ms < u128::from(self.min_interval_ms) {
            return Ok(()); // 未到发送间隔, 跳过
        }
        self.last_send_ms = now_ms;

        // 5. 组帧并发送
        let frame = Self::build_frame(&angles);
        self.send_count += 1;
        println!(
            "[PWM-SEND] #{} id={:?} -> deg={:?} frame={}",
            self.send_count,
            ids,
            angles,
            frame.iter().map(|b| format!("{b:02X}")).collect::<Vec<_>>().join(" ")
        );
        self.port
            .write_all(&frame)
            .map_err(|e| eyre!("write PWM frame failed: {e}"))?;

        // 6. 顺带读回包: 统计 ESP32 回 ACK 数量 (每 30 帧汇报一次)
        let mut buf = [0u8; 256];
        let mut scanned = Vec::new();
        loop {
            match self.port.read(&mut buf) {
                Ok(n) if n > 0 => scanned.extend_from_slice(&buf[..n]),
                _ => break, // 超时或无数据, 停止读取
            }
        }
        let ack = [0xBB, CMD_DIRECT_DRIVE, 0x00, CMD_DIRECT_DRIVE];
        if scanned.len() >= 4 {
            for w in scanned.windows(4) {
                if w == ack {
                    self.ack_count += 1;
                }
            }
        }
        if self.send_count % 30 == 0 {
            println!(
                "[ACK-STATS] sent {} frames, ESP32 acked {} frames",
                self.send_count, self.ack_count
            );
        }
        Ok(())
    }
}

impl ServoBackend for PwmBackend {
    fn torque_enable(&mut self, _ids: &[u8], _on: bool) -> Result<()> {
        // PWM 舵机无上电概念, no-op
        Ok(())
    }

    fn write_goal_positions(&mut self, ids: &[u8], goals_rad: &[f64]) -> Result<()> {
        self.send_angles(ids, goals_rad)
    }

    fn name(&self) -> &'static str {
        "pwm"
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rad_to_deg() {
        // rad=0 → 90°(中立), 限制在 [20, 160]
        assert_eq!(PwmBackend::rad_to_deg(0.0, 90), 90);
        assert_eq!(PwmBackend::rad_to_deg(std::f64::consts::FRAC_PI_2, 90), MAX_ANGLE);
        assert_eq!(PwmBackend::rad_to_deg(-std::f64::consts::FRAC_PI_2, 90), MIN_ANGLE);
        // clamp
        assert_eq!(PwmBackend::rad_to_deg(3.0, 90), MAX_ANGLE);
        assert_eq!(PwmBackend::rad_to_deg(-3.0, 90), MIN_ANGLE);
    }

    #[test]
    fn test_build_frame() {
        // 全部 90° 中立: AA F0 08 5A...5A, checksum = F0^08 = F8
        let angles = [90u8; NUM_SERVOS];
        let f = PwmBackend::build_frame(&angles);
        assert_eq!(&f[0..3], &[0xAA, 0xF0, 0x08]);
        assert_eq!(&f[3..11], &[0x5A; 8]);
        assert_eq!(f[11], 0xF8);
        // 全 0°: checksum = F0^08^0... = F8
        let angles = [0u8; NUM_SERVOS];
        let f = PwmBackend::build_frame(&angles);
        assert_eq!(f[11], 0xF0 ^ 0x08);
    }
}
